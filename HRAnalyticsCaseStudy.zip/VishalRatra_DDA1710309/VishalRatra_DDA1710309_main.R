################## HR Analytics Case Study #######################
################## CRISP - DM Framework    ########################
#Business Understanding
#Data Understanding
#Data Preparation & EDA
#Model Building 
#Model Evaluation
################## Business Understanding##########################

# A company by name XYZ has around 15 % attrition rate,this is hhigh and a potential loss
# to the organisation as it causes delay in project and loss of reputation


## AIM:

# Find the factors which affect the attriton in the company, so that they can change worplace practises

# Whether a person attrites of not will depend on data from the following 4 buckets:

# 1. Employee Survey
# 2. Time Sheet Information
# 3. Manager Feedback
# 4. Demographic & Personal Information.



################## Data Understanding ####
# Loading the required packages
if (!require('MASS')) install.packages('MASS')
if (!require('car')) install.packages('car')
if (!require('ggplot2')) install.packages('ggplot2')
if (!require('tidyverse')) install.packages('tidyverse')
if (!require('GGally')) install.packages('GGally')
if (!require('cowplot')) install.packages('cowplot')
if (!require('caret')) install.packages('caret',dependencies = c("Depends", "Suggests"))
if (!require('e1071')) install.packages('e1071')
if (!require('caTools')) install.packages('caTools')
if (!require('lubridate')) install.packages('lubridate')


library(tidyverse)
library(lubridate)
library(MASS)
library(car)
library(e1071)
library(caret)
library(ggplot2)
library(cowplot)
library(caTools)
library(GGally)


# Loading the Employee survey data
Employee_Srvy <- read.csv("employee_survey_data.csv", stringsAsFactors = FALSE)

# Loading the timesheet dataset
in_time <- read.csv("in_time.csv")
out_time <- read.csv("out_time.csv")

# Loading the General Data
General_Data <- read.csv("general_data.csv", stringsAsFactors = FALSE)

# Manager Survey Data
Mgr_Srvy <- read.csv("manager_survey_data.csv", stringsAsFactors = FALSE)

# Check the structure of the data 
str(Employee_Srvy) # 4410 observations of 4 variables
str(General_Data) # 4410 observations of 24 variables
str(Mgr_Srvy) # 4410 observations of 3 variables
str(in_time) # 4410 observations of 262 variables ,looks like there are 262 business days
str(out_time) # 4410 observations of 262 variables ,looks like there are 262 business days


# Check for unique IDs of Employees
length(unique(Employee_Srvy$EmployeeID))    # 4410, confirming Employee ID is key 
length(unique(General_Data$EmployeeID)) # 4410, confirming Employee ID is key
length(unique(Mgr_Srvy$EmployeeID)) # 4410, confirming Employee ID is key
length(unique(in_time$X)) # 4410, confirming X is key
length(unique(out_time$X)) # 4410, confirming X is key

setdiff(Employee_Srvy$EmployeeID,General_Data$EmployeeID) # Identical Employee ID across these datasets
setdiff(Employee_Srvy$EmployeeID,Mgr_Srvy$EmployeeID) # Identical EmployeeID across these datasets
setdiff(Employee_Srvy$EmployeeID,in_time$X) # Identical EmployeeID across these datasets
setdiff(Employee_Srvy$EmployeeID,in_time$X) # Identical EmployeeID across these datasets

# Merge the data of employees
Employee_Master <- merge(General_Data, Employee_Srvy, by = "EmployeeID", all = F) # all is false do inner join
Employee_Master <- merge(Employee_Master,Mgr_Srvy, by = "EmployeeID", all = F) # all is false do inner join

View(Employee_Master)
# The timesheet data will be cleaned in the data preparation stage and merged with the master data.


################## Data Preparation & Exploratory Data Analysis ####
# Handling and preparing the time sheet data
# Convert into date time object

# columns with all NAs -> representing the holidays ! 
idx_allNAs <- as.numeric(which(sapply(in_time, function(x)all(is.na(x)))))
idx_allNAs2 <- as.numeric(which(sapply(out_time, function(x)all(is.na(x)))))

# Finding the position in both in and out dataframes where NAs are present
# as they are at same location it indicates that they are absent and not a swipe issue.
# Removing 1st column and columns with all NAs, which seems holidays

cnv_in <- data.frame(lapply(in_time[,-c(1,idx_allNAs)],ymd_hms))
cnv_out <- data.frame(lapply(out_time[,-c(1,idx_allNAs2)],ymd_hms))
dursec <- cnv_out - cnv_in

hrsworked <- as.data.frame(lapply(dursec, as.numeric))

# Create derived metrics like mean hours worked, median hours worked and iqr of time spent
hrsworked$MeansHrs <- apply(hrsworked,1,function(x){mean(x[!is.na(x)])})
hrsworked$MedianHrs <- apply(hrsworked,1,function(x){median(x[!is.na(x)])})
hrsworked$IqrHrs <- apply(hrsworked,1,function(x){IQR(x[!is.na(x)])})

#Understand the structure of data
str(hrsworked)
# Append the new metrics to Employee master data
Employee_Master <- cbind(Employee_Master, hrsworked[,250:252])
# Understanding the structure of the Master file
str(Employee_Master) #4410 obs. of 32 variables;

# Dropping the variables which will not add any values Employee ID, Employee Count,Over18,Standard Hour & MeansHrs
unique(Employee_Master$EmployeeCount) # 1
unique(Employee_Master$Over18) # Yes
unique(Employee_Master$StandardHours) # 8

# Drop variables : Above variables and mean hours and employee IDs
dropvars <- c("EmployeeID","EmployeeCount","Over18","StandardHours","MeansHrs")
Employee_Master <- Employee_Master[ , !(names(Employee_Master) %in% dropvars)]
str(Employee_Master) #4410 obs. of 27 variables

# Visually Exploring the categorical and numeric variables

# Exploring the 12 quatitative variables
#Age,DistanceFromHome,MonthlyIncome,NumCompaniesWorked,PercentSalaryHike,TotalWorkingYears,
# TrainingTimesLastYear,YearsAtCompany,YearsSinceLastPromotion,YearsWithCurrManager,MedianHrs,IqrHrs

# Univariate Analysis
# Histogram and Boxplots for numeric variables 
box_theme <- theme(axis.line = element_blank(),axis.title = element_blank(), 
                  axis.ticks = element_blank(), axis.text = element_blank())

box_theme_y <- theme(axis.line.y = element_blank(),axis.title.y = element_blank(), 
                    axis.ticks.y = element_blank(), axis.text.y = element_blank(),
                    legend.position = "none")

#Age
#Median Age of Employees: 39, 25th Percentile: 28.5, 75th Percentile : 49.5, Inter quantile Range: 21
#No outliers found for Age
plot_grid(ggplot(Employee_Master, aes(Age)) + geom_histogram(binwidth = 5),
          ggplot(Employee_Master, aes(x = "",y = Age)) + geom_boxplot(width = 0.1) + coord_flip() + box_theme, 
          align = "v",ncol = 1)

# Distance From Home
# Median distance from Home: 7, Around 75% employees stay within 14 kms from office
# There are no outliers
plot_grid(ggplot(Employee_Master, aes(DistanceFromHome)) + geom_histogram(binwidth = 10),
          ggplot(Employee_Master, aes(x = "",y = DistanceFromHome)) + geom_boxplot(width = 0.1) + coord_flip() + box_theme, 
          align = "v",ncol = 1)

# Monthly income
# Median Income: 49190, 75% of employees earn below 85000
# There are outlier values which are above 165 550
plot_grid(ggplot(Employee_Master, aes(MonthlyIncome)) + geom_histogram(binwidth = 10000),
          ggplot(Employee_Master, aes(x = "",y = MonthlyIncome)) + geom_boxplot(width = 0.1) + coord_flip() + box_theme, 
          align = "v",ncol = 1)

# Num of companies worked
# Median No of Companies: 2 25th Percentile: 1, 75th Percentile : 4
# There are some outliers
plot_grid(ggplot(Employee_Master, aes(NumCompaniesWorked)) + geom_histogram(binwidth = 1),
          ggplot(Employee_Master, aes(x = "",y = NumCompaniesWorked)) + geom_boxplot(width = 0.1) + coord_flip() + box_theme, 
          align = "v",ncol = 1)

# Salary Hike
# Median Salary Hike: 14%, 25th Percentile: 12%, 75th Percentile : 18%
# No outliers
plot_grid(ggplot(Employee_Master, aes(PercentSalaryHike)) + geom_histogram(binwidth = 5),
          ggplot(Employee_Master, aes(x = "",y = PercentSalaryHike)) + geom_boxplot(width = 0.1) + coord_flip() + box_theme, 
          align = "v",ncol = 1)

# Total Working Years
# Median Working Years: 10 25th Percentile: 6, 75th Percentile : 15
# There are many outlier values
# Maximum employees are below 10 years
plot_grid(ggplot(Employee_Master, aes(TotalWorkingYears)) + geom_histogram(binwidth = 5),
          ggplot(Employee_Master, aes(x = "",y = TotalWorkingYears)) + geom_boxplot(width = 0.1) + coord_flip() + box_theme, 
          align = "v",ncol = 1)


# TrainingTimesLastYear
# Median Years at company: 3, 25th Percentile: 2 75th Percentile : 3
# Median is same as 75th percentile
# There are some outlier values 
plot_grid(ggplot(Employee_Master, aes(TrainingTimesLastYear)) + geom_histogram(binwidth = 1),
          ggplot(Employee_Master, aes(x = "",y = TrainingTimesLastYear)) + geom_boxplot(width = 0.1) + coord_flip() + box_theme, 
          align = "v",ncol = 1)

# YearsAtCompany
# Median Years at company: 5 
# 25th Percentile: 3 75th Percentile : 9 
# There are many outliers
plot_grid(ggplot(Employee_Master, aes(YearsAtCompany)) + geom_histogram(binwidth = 5),
          ggplot(Employee_Master, aes(x = "",y = YearsAtCompany)) + geom_boxplot(width = 0.1) + coord_flip() + box_theme, 
          align = "v",ncol = 1)

# YearsSinceLastPromotion
# Median : 1, 25th Percentile: 0, 75th Percentile : 3
# There are some outliers  
plot_grid(ggplot(Employee_Master, aes(YearsSinceLastPromotion)) + geom_histogram(binwidth = 2),
          ggplot(Employee_Master, aes(x = "",y = YearsSinceLastPromotion)) + geom_boxplot(width = 0.1) + coord_flip() + box_theme, 
          align = "v",ncol = 1)

# YearsWithCurrManager,
# Median : 3, 25th Percentile: 2, 75th Percentile : 7
# There are many outlier values
plot_grid(ggplot(Employee_Master, aes(YearsWithCurrManager)) + geom_histogram(binwidth = 2),
          ggplot(Employee_Master, aes(x = "",y = YearsWithCurrManager)) + geom_boxplot(width = 0.1) + coord_flip() + box_theme, 
          align = "v",ncol = 1)

# MedianHrs
# Median ~ 7 , 25th Percentile ~ 6, 75th Percentile ~ 8.8
# There are some outliers 
plot_grid(ggplot(Employee_Master, aes(MedianHrs)) + geom_histogram(binwidth = 2),
          ggplot(Employee_Master, aes(x = "",y = MedianHrs)) + geom_boxplot(width = 0.1) + coord_flip() + box_theme, 
          align = "v",ncol = 1)

# IqrHrs : there are outliers
plot_grid(ggplot(Employee_Master, aes(IqrHrs)) + geom_histogram(binwidth = .1),
          ggplot(Employee_Master, aes(x = "",y = IqrHrs)) + geom_boxplot(width = 0.1) + coord_flip() + box_theme, 
          align = "v",ncol = 1)

#outlier, confirming it also with percentiles
outliers <- sapply(Employee_Master[,c("Age","DistanceFromHome","MonthlyIncome","NumCompaniesWorked","PercentSalaryHike","TotalWorkingYears",
                          "TrainingTimesLastYear","YearsAtCompany","YearsSinceLastPromotion","YearsWithCurrManager",
                          "MedianHrs","IqrHrs")], 
       function(x) quantile(x,seq(0,1,.01),na.rm = T)) #

#Segmented Univariate Analysis of Numerical Variables
# Boxplots of numeric variables relative to Attrition status

# Age - Medians: Attrition:32 Non Attrition: 36 , Inference: More attrition if Age is lower, strong indicator
# Distance From Home - Medians:7 Attrition: Non Attrition: 7 , Inference: Not much difference in plots, not a strong indicator
# Monthly Income - Medians: Attrition:49080 Non Attrition:49380, Inference: 75% of emp who attrite have income less than 70k
# Num of Companies worked - Medians:Attrition:1 Non Attrition:2, Inference: Emp who attrite change companies more often than who don't
# Percent Salary Hike - Medians: Attrition:14 Non Attrition:14, Inference: Plots are almost similar, not a strong indicator
# Total Working Years - Medians: Attrition:7 Non Attrition:10 , Inference: Emp from 3-10 years are more likely to attrite, strong indicator
plot_grid(ggplot(Employee_Master, aes(x = Attrition,y = Age, fill = Attrition)) + geom_boxplot(width = 0.1) + 
            coord_flip() + theme(legend.position = "none"),
          ggplot(Employee_Master, aes(x = Attrition,y = DistanceFromHome, fill = Attrition)) + geom_boxplot(width = 0.1) +
            coord_flip() + box_theme_y,
          ggplot(Employee_Master, aes(x = Attrition,y = MonthlyIncome, fill = Attrition)) + geom_boxplot(width = 0.1) +
            coord_flip() + box_theme_y,
          ggplot(Employee_Master, aes(x = Attrition,y = NumCompaniesWorked, fill = Attrition)) + geom_boxplot(width = 0.1) +
            coord_flip() + box_theme_y,
          ggplot(Employee_Master, aes(x = Attrition,y = PercentSalaryHike, fill = Attrition)) + geom_boxplot(width = 0.1) +
            coord_flip() + box_theme_y,
          ggplot(Employee_Master, aes(x = Attrition,y = TotalWorkingYears, fill = Attrition)) + geom_boxplot(width = 0.1) +
            coord_flip() + box_theme_y,
          align = "v",nrow = 1)

# Medians Attrition:, Non-Attrition: , Inference:
# Training Times Last Year - Medians Attrition:3, Non-Attrition:3 , Inference: Doesn't seem to a be strong Indicator 
# Years At company - Medians Attrition:3, Non-Attrition:6 , Inference: Lesser no of years in company, more likely to attrite
# Years Since Last promotion - Medians Attrition:1, Non-Attrition:1 , Inference:Mostly employees who attrite have been promoted before 2 years
# Years with current Manager - Medians Attrition:2, Non-Attrition:3 , Inference: Employees with new manager attrite much more, strong indicator
# Median Hrs - Medians Attrition: 8.8, Non-Attrition:7.5 , Inference: Higher Median hours ~ more chances of attrition, strong indicator
# IQR Hrs - Medians Attrition:, Non-Attrition: , Inference: 
plot_grid(ggplot(Employee_Master, aes(x = Attrition,y = TrainingTimesLastYear, fill = Attrition)) + geom_boxplot(width = 0.1) +
            coord_flip() + theme(legend.position = "none"),
          ggplot(Employee_Master, aes(x = Attrition,y = YearsAtCompany, fill = Attrition)) + geom_boxplot(width = 0.1) +
            coord_flip() + box_theme_y,
          ggplot(Employee_Master, aes(x = Attrition,y = YearsSinceLastPromotion, fill = Attrition)) + geom_boxplot(width = 0.1) +
            coord_flip() + box_theme_y,
          ggplot(Employee_Master, aes(x = Attrition,y = YearsWithCurrManager, fill = Attrition)) + geom_boxplot(width = 0.1) +
            coord_flip() + box_theme_y,
          ggplot(Employee_Master, aes(x = Attrition,y = MedianHrs, fill = Attrition)) + geom_boxplot(width = 0.1) +
            coord_flip() + box_theme_y,
          ggplot(Employee_Master, aes(x = Attrition,y = IqrHrs, fill = Attrition)) + geom_boxplot(width = 0.1) +
            coord_flip() + box_theme_y,
          align = "v",nrow = 1)


# Hypothesis : Age, NumCompaniesWorked,TotalWorkingYears,YearsAtCompany,YearsWithCurrManager,MedianHrs
# seems to be the driver factors to distinguish Attrition from Non-Attrition,. These observations shall be corroborated with
# Model results

# Correlation among numeric variables
ggpairs(Employee_Master[, c("Age","DistanceFromHome","MonthlyIncome","NumCompaniesWorked","PercentSalaryHike","TotalWorkingYears",
                            "TrainingTimesLastYear","YearsAtCompany","YearsSinceLastPromotion","YearsWithCurrManager",
                            "MedianHrs","IqrHrs")])

# Observation :Years at a company are highly correlated with years since promotions and years with current manager 
# Age is highly correlated to total working years 

# EDA of Categorical variables
# Barcharts for categorical features with stacked Attrition information
bar_theme1 <- theme(axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5), 
                   legend.position = "none")

# Business Travel - Inference: People who travel frequently have higher chances of attrition, Strong Indicator
# Department - Inference: No clear indication of attrition within depts though proportionally HR dept has higher attrition
# Education - Inference: No clear indication of attrition based on education levels. 
# Education Field - - Inference: HR Field has quite low no of emps however higher attrition levels. 

plot_grid(ggplot(Employee_Master, aes(x = factor(BusinessTravel),fill = Attrition)) + geom_bar(position = "fill"), 
          ggplot(Employee_Master, aes(x = factor(Department),fill = Attrition)) + geom_bar(position = "fill") + bar_theme1,
          ggplot(Employee_Master, aes(x = factor(Education),fill = Attrition)) + geom_bar(position = "fill") + bar_theme1,
          ggplot(Employee_Master, aes(x = factor(EducationField),fill = Attrition)) + geom_bar(position = "fill") + bar_theme1,
          align = "h")

# Gender - Inference: Males are higher in count than females, attrition levels proportional, not a strong indicator
# Job Level - Inference: Job Level 2 has more attrition than other levels, however not a much high difference. 
# Job Role - Inference: Research and Manufacturing Directors have much attritions, Strong indicator
# Marital Status - Inference:Singles are the most likely to attrite, Strong indicator
plot_grid(ggplot(Employee_Master, aes(x = factor(Gender),fill = Attrition)) + geom_bar(position = "fill") + bar_theme1,
          ggplot(Employee_Master, aes(x = factor(JobLevel),fill = Attrition)) + geom_bar(position = "fill") + bar_theme1,
          ggplot(Employee_Master, aes(x = factor(JobRole),fill = Attrition)) + geom_bar(position = "fill") + bar_theme1,
          ggplot(Employee_Master, aes(x = factor(MaritalStatus),fill = Attrition)) + geom_bar(position = "fill") + bar_theme1,
          align = "h")

# Stock Option Level - Inference: Attrition Levels doesn't seem to be dependent on the Stock Options
# Environment Satisfaction - Inference:Attrition Levels are quite high when the Satisfaction rating is 1, Strong indicator
# Job Satisfaction - Inference: There is more attrition level when Job Satisfaction rating is 1, Strong indicator
# Work Life Balance - Inference: Work Life Balance rating 1 -> more attrition, though not as strong as some of the others
plot_grid(ggplot(Employee_Master, aes(x = factor(StockOptionLevel),fill = Attrition)) + geom_bar(position = "fill") + bar_theme1,
          ggplot(Employee_Master, aes(x = factor(EnvironmentSatisfaction),fill = Attrition)) + geom_bar(position = "fill") + bar_theme1,
          ggplot(Employee_Master, aes(x = factor(JobSatisfaction),fill = Attrition)) + geom_bar(position = "fill") + bar_theme1,
          ggplot(Employee_Master, aes(x = factor(WorkLifeBalance),fill = Attrition)) + geom_bar(position = "fill") + bar_theme1,
          align = "h")

# Job Involvement - Inference: There is no clear trend of Attrition based on Job Involvement. 
# Performance Rating - Inference: No clear indication for attrition based on performance rating
plot_grid(ggplot(Employee_Master, aes(x = factor(JobInvolvement),fill = Attrition)) + geom_bar(position = "fill") + bar_theme1,
          ggplot(Employee_Master, aes(x = factor(PerformanceRating),fill = Attrition)) + geom_bar(position = "fill") + bar_theme1,
          align = "h")  

# Reveals Strong indications for Job Role - Reasearch Director, Marital Status - Single,HR Education Field, HR - Department, Frequent Travel,Work Life Balance,JobSatisfaction
# and Environment Satisfaction

# Treatment of outliers

Employee_Master$MonthlyIncome[which(Employee_Master$MonthlyIncome > 165550)] <- 165550
Employee_Master$TotalWorkingYears[which(Employee_Master$TotalWorkingYears > 28)] <- 28
Employee_Master$YearsAtCompany[which(Employee_Master$YearsAtCompany > 20)] <- 20
Employee_Master$YearsSinceLastPromotion[which(Employee_Master$YearsSinceLastPromotion > 9)] <- 9
Employee_Master$YearsWithCurrManager[which(Employee_Master$YearsWithCurrManager > 14)] <- 14
Employee_Master$MedianHrs[which(Employee_Master$MedianHrs > 10.6)] <- 10.6
Employee_Master$IqrHrs[which(Employee_Master$IqrHrs > .47125)] <- .47125
Employee_Master$IqrHrs[which(Employee_Master$IqrHrs < .3326514)] <- .3326514

# Missing value treatment
dfm <- data.frame(sapply(Employee_Master, function(x) sum(is.na(x)))) # shows 5 columns with NAs)

# Lets look at the dataframe then ! 
View(subset(Employee_Master, is.na(WorkLifeBalance)))
View(subset(Employee_Master, is.na(EnvironmentSatisfaction)))
View(subset(Employee_Master, is.na(JobSatisfaction)))
View(subset(Employee_Master, is.na(NumCompaniesWorked)))
View(subset(Employee_Master, is.na(TotalWorkingYears)))

# What percentage is having NAs
sum(dfm$sapply.Employee_Master..function.x..sum.is.na.x...)
# It means that 111/4410 = 0.0270073 i.e 2.7%, best is to remove these observations from the analysis
Employee_Master <- Employee_Master[!is.na(Employee_Master$WorkLifeBalance),]
Employee_Master <- Employee_Master[!is.na(Employee_Master$EnvironmentSatisfaction),]
Employee_Master <- Employee_Master[!is.na(Employee_Master$JobSatisfaction),]
Employee_Master <- Employee_Master[!is.na(Employee_Master$NumCompaniesWorked),]
Employee_Master <- Employee_Master[!is.na(Employee_Master$TotalWorkingYears),]


# Feature standardisation

# Normalising continuous features

Employee_Master$Age <- scale(Employee_Master$Age) 
Employee_Master$DistanceFromHome <- scale(Employee_Master$DistanceFromHome) 
Employee_Master$MonthlyIncome <- scale(Employee_Master$MonthlyIncome)
Employee_Master$NumCompaniesWorked <- scale(Employee_Master$NumCompaniesWorked)
Employee_Master$TotalWorkingYears <- scale(Employee_Master$TotalWorkingYears)
Employee_Master$TrainingTimesLastYear <- scale(Employee_Master$TrainingTimesLastYear)
Employee_Master$YearsAtCompany <- scale(Employee_Master$YearsAtCompany)
Employee_Master$YearsSinceLastPromotion <- scale(Employee_Master$YearsSinceLastPromotion)
Employee_Master$YearsWithCurrManager <- scale(Employee_Master$YearsWithCurrManager)
Employee_Master$PercentSalaryHike <- scale(Employee_Master$PercentSalaryHike)
Employee_Master$MedianHrs <- scale(Employee_Master$MedianHrs)
Employee_Master$IqrHrs <- scale(Employee_Master$IqrHrs)


# converting target variable Attrition from No/Yes character to factorwith levels 0/1 
Employee_Master$Attrition <- ifelse(Employee_Master$Attrition == "Yes", 1, 0)

# Checking attrition rate of employees

Attrition <- sum(Employee_Master$Attrition)/nrow(Employee_Master)
Attrition # 16.16 % Attrition Rate. 

# creating a dataframe of categorical features
Employee_Master_chr <- Employee_Master[,c(3:4,6:11,15,21:25)]

# converting categorical attributes to factor
Employee_Master_fact <- data.frame(sapply(Employee_Master_chr, function(x) factor(x)))
str(Employee_Master_fact)

# Checking what levels are associated with which sub-category
data.frame(levels = unique(Employee_Master_fact$BusinessTravel), value = as.numeric(unique(Employee_Master_fact$BusinessTravel)))
# levels value
#      Travel_Rarely     3
#  Travel_Frequently     2
#         Non-Travel     1
data.frame(levels = unique(Employee_Master_fact$Department), value = as.numeric(unique(Employee_Master_fact$Department)))
# levels value
#                   Sales     3
#  Research & Development     2
#         Human Resources     1
data.frame(levels = unique(Employee_Master_fact$Education), value = as.numeric(unique(Employee_Master_fact$Education)))
# levels value
#       2     2
#       1     1
#       4     4
#       5     5
#       3     3
data.frame(levels = unique(Employee_Master_fact$EducationField), value = as.numeric(unique(Employee_Master_fact$EducationField)))
# #           levels value
#     Life Sciences     2
#             Other     5
#           Medical     4
#         Marketing     3
#  Technical Degree     6
#   Human Resources     1
data.frame(levels = unique(Employee_Master_fact$Gender), value = as.numeric(unique(Employee_Master_fact$Gender)))
# levels value
#  Female     1 0
#  Male     2 1 
data.frame(levels = unique(Employee_Master_fact$JobLevel), value = as.numeric(unique(Employee_Master_fact$JobLevel)))
# levels value
#       1     1
#       4     4
#       3     3
#       2     2
#       5     5
data.frame(levels = unique(Employee_Master_fact$JobRole), value = as.numeric(unique(Employee_Master_fact$JobRole)))
# levels value
# Healthcare Representative     1
#         Research Scientist     7
#           Sales Executive     8
#            Human Resources     2
#         Research Director     6
#      Laboratory Technician     3
#     Manufacturing Director     5
#       Sales Representative     9
#                   Manager     4
data.frame(levels = unique(Employee_Master_fact$MaritalStatus), value = as.numeric(unique(Employee_Master_fact$MaritalStatus)))
# levels value
#   Married     2
#    Single     3
#  Divorced     1
data.frame(levels = unique(Employee_Master_fact$StockOptionLevel), value = as.numeric(unique(Employee_Master_fact$StockOptionLevel)))
# levels value
#      0     1
#      1     2
#       3     4
#       2     3
data.frame(levels = unique(Employee_Master_fact$EnvironmentSatisfaction), value = as.numeric(unique(Employee_Master_fact$EnvironmentSatisfaction)))
# levels value
#       3     3
#       2     2
#       4     4
#       1     1
data.frame(levels = unique(Employee_Master_fact$JobSatisfaction), value = as.numeric(unique(Employee_Master_fact$JobSatisfaction)))
# levels value
#       4     4
#       2     2
#       1     1
#       3     3
data.frame(levels = unique(Employee_Master_fact$WorkLifeBalance), value = as.numeric(unique(Employee_Master_fact$WorkLifeBalance)))
# levels value
#       2     2
#       4     4
#       1     1
#       3     3
data.frame(levels = unique(Employee_Master_fact$JobInvolvement), value = as.numeric(unique(Employee_Master_fact$JobInvolvement)))
# levels value
#       3     3
#       2     2
#       4     4
#       1     1
data.frame(levels = unique(Employee_Master_fact$PerformanceRating), value = as.numeric(unique(Employee_Master_fact$PerformanceRating)))
# levels value
#       3     1  0
#       4     2  1


# creating dummy variables for factor attributes
dummies <- data.frame(sapply(Employee_Master_fact, 
                            function(x) data.frame(model.matrix(~x-1,data = Employee_Master_fact))[,-1]))

# For variables having only two levels, Performance Rating 4 level is 1 , Gender Male is 1,


# Final dataset
Employee_Master_final <- cbind(Employee_Master[,-c(3:4,6:11,15,21:25)],dummies) 
View(Employee_Master_final) #4300 of 57 variables

### Model Development ######
# splitting the data between train and test
set.seed(100)

indices <- sample.split(Employee_Master_final$Attrition, SplitRatio = 0.7)

train <- Employee_Master_final[indices,]

test <- Employee_Master_final[!(indices),]

# Logistic Regression: 

#Initial model
model_1 = glm(Attrition ~ ., data = train, family = "binomial")
summary(model_1) #AIC 2114.4

# Stepwise selection
model_2 <- stepAIC(model_1, direction = "both")

summary(model_2)

# Removing multicollinearity through VIF check

df_vif <- data.frame(vif(model_2))

# Department sales has high significane and high VIF 
model_3 <- glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + 
                 TrainingTimesLastYear + YearsSinceLastPromotion + YearsWithCurrManager + 
                 MedianHrs + BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                 Department.xResearch...Development +  
                 Education.x5 + EducationField.xLife.Sciences + EducationField.xMarketing + 
                 EducationField.xMedical + EducationField.xOther + EducationField.xTechnical.Degree + 
                 JobLevel.x2 + JobLevel.x5 + JobRole.xHuman.Resources + JobRole.xManager + 
                 JobRole.xManufacturing.Director + JobRole.xResearch.Director + 
                 JobRole.xSales.Executive + MaritalStatus.xSingle + StockOptionLevel.x1 + 
                 EnvironmentSatisfaction.x2 + EnvironmentSatisfaction.x3 + 
                 EnvironmentSatisfaction.x4 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
                 JobSatisfaction.x4 + WorkLifeBalance.x2 + WorkLifeBalance.x3 + 
                 WorkLifeBalance.x4 + JobInvolvement.x3, family = "binomial", 
               data = train)

#AIC: 2089. 7 hasn't changed much ,so we can remove this variable
summary(model_3)
df_vif <- data.frame(vif(model_3))

# Remove Life sciencies high VIF

model_4 <- glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + 
                 TrainingTimesLastYear + YearsSinceLastPromotion + YearsWithCurrManager + 
                 MedianHrs + BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                 Department.xResearch...Development + Education.x5 +  
                 EducationField.xMarketing + EducationField.xMedical + EducationField.xOther + 
                 EducationField.xTechnical.Degree + JobLevel.x2 + JobLevel.x5 + 
                 JobRole.xHuman.Resources + JobRole.xManager + JobRole.xManufacturing.Director + 
                 JobRole.xResearch.Director + JobRole.xSales.Executive + MaritalStatus.xSingle + 
                 StockOptionLevel.x1 + EnvironmentSatisfaction.x2 + EnvironmentSatisfaction.x3 + 
                 EnvironmentSatisfaction.x4 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
                 JobSatisfaction.x4 + WorkLifeBalance.x2 + WorkLifeBalance.x3 + 
                 WorkLifeBalance.x4 + JobInvolvement.x3, family = "binomial", 
               data = train)

#AIC: 2100.4 hasn't changed much ,so we can remove this variable
summary(model_4)
df_vif <- data.frame(vif(model_4))

# Education field medical
model_5 <- glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + 
                 TrainingTimesLastYear + YearsSinceLastPromotion + YearsWithCurrManager + 
                 MedianHrs + BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                 Department.xResearch...Development + Education.x5 + EducationField.xMarketing + 
                  EducationField.xOther + EducationField.xTechnical.Degree + 
                 JobLevel.x2 + JobLevel.x5 + JobRole.xHuman.Resources + JobRole.xManager + 
                 JobRole.xManufacturing.Director + JobRole.xResearch.Director + 
                 JobRole.xSales.Executive + MaritalStatus.xSingle + StockOptionLevel.x1 + 
                 EnvironmentSatisfaction.x2 + EnvironmentSatisfaction.x3 + 
                 EnvironmentSatisfaction.x4 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
                 JobSatisfaction.x4 + WorkLifeBalance.x2 + WorkLifeBalance.x3 + 
                 WorkLifeBalance.x4 + JobInvolvement.x3, family = "binomial", 
               data = train)

#AIC: 2099.6 hasn't changed much ,so we can remove this variable
summary(model_5)
df_vif <- data.frame(vif(model_5))

# Education field other
model_6 <- glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + 
                 TrainingTimesLastYear + YearsSinceLastPromotion + YearsWithCurrManager + 
                 MedianHrs + BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                 Department.xResearch...Development + Education.x5 + EducationField.xMarketing + 
                  EducationField.xTechnical.Degree + 
                 JobLevel.x2 + JobLevel.x5 + JobRole.xHuman.Resources + JobRole.xManager + 
                 JobRole.xManufacturing.Director + JobRole.xResearch.Director + 
                 JobRole.xSales.Executive + MaritalStatus.xSingle + StockOptionLevel.x1 + 
                 EnvironmentSatisfaction.x2 + EnvironmentSatisfaction.x3 + 
                 EnvironmentSatisfaction.x4 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
                 JobSatisfaction.x4 + WorkLifeBalance.x2 + WorkLifeBalance.x3 + 
                 WorkLifeBalance.x4 + JobInvolvement.x3, family = "binomial", 
               data = train)
#AIC: 2099.1 hasn't changed much ,so we can remove this variable
summary(model_6)
df_vif <- data.frame(vif(model_6))

# Technical degree
model_7 <- glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + 
                 TrainingTimesLastYear + YearsSinceLastPromotion + YearsWithCurrManager + 
                 MedianHrs + BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                 Department.xResearch...Development + Education.x5 + EducationField.xMarketing + 
                  JobLevel.x2 + JobLevel.x5 + 
                 JobRole.xHuman.Resources + JobRole.xManager + JobRole.xManufacturing.Director + 
                 JobRole.xResearch.Director + JobRole.xSales.Executive + MaritalStatus.xSingle + 
                 StockOptionLevel.x1 + EnvironmentSatisfaction.x2 + EnvironmentSatisfaction.x3 + 
                 EnvironmentSatisfaction.x4 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
                 JobSatisfaction.x4 + WorkLifeBalance.x2 + WorkLifeBalance.x3 + 
                 WorkLifeBalance.x4 + JobInvolvement.x3, family = "binomial", 
               data = train)
#AIC: 2099.3 hasn't changed much ,so we can remove this variable
summary(model_7)
df_vif <- data.frame(vif(model_7))

# job level 5
model_8 <- glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + 
                 TrainingTimesLastYear + YearsSinceLastPromotion + YearsWithCurrManager + 
                 MedianHrs + BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                 Department.xResearch...Development + Education.x5 + EducationField.xMarketing + 
                 JobLevel.x2 +  JobRole.xHuman.Resources + JobRole.xManager + 
                 JobRole.xManufacturing.Director + JobRole.xResearch.Director + 
                 JobRole.xSales.Executive + MaritalStatus.xSingle + StockOptionLevel.x1 + 
                 EnvironmentSatisfaction.x2 + EnvironmentSatisfaction.x3 + 
                 EnvironmentSatisfaction.x4 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
                 JobSatisfaction.x4 + WorkLifeBalance.x2 + WorkLifeBalance.x3 + 
                 WorkLifeBalance.x4 + JobInvolvement.x3, family = "binomial", 
               data = train)
#AIC: 2099.7 hasn't changed much ,so we can remove this variable
summary(model_8)
df_vif <- data.frame(vif(model_8))

# Marketing
model_9 <- glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + 
                 TrainingTimesLastYear + YearsSinceLastPromotion + YearsWithCurrManager + 
                 MedianHrs + BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                 Department.xResearch...Development + Education.x5 +  
                 JobLevel.x2 + JobRole.xHuman.Resources + JobRole.xManager + 
                 JobRole.xManufacturing.Director + JobRole.xResearch.Director + 
                 JobRole.xSales.Executive + MaritalStatus.xSingle + StockOptionLevel.x1 + 
                 EnvironmentSatisfaction.x2 + EnvironmentSatisfaction.x3 + 
                 EnvironmentSatisfaction.x4 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
                 JobSatisfaction.x4 + WorkLifeBalance.x2 + WorkLifeBalance.x3 + 
                 WorkLifeBalance.x4 + JobInvolvement.x3, family = "binomial", 
               data = train)
#AIC: 2100.5 hasn't changed much ,so we can remove this variable
summary(model_9)
df_vif <- data.frame(vif(model_9))

# Research & Development Department
model_10 <- glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + 
                  TrainingTimesLastYear + YearsSinceLastPromotion + YearsWithCurrManager + 
                  MedianHrs + BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                   Education.x5 + JobLevel.x2 + 
                  JobRole.xHuman.Resources + JobRole.xManager + JobRole.xManufacturing.Director + 
                  JobRole.xResearch.Director + JobRole.xSales.Executive + MaritalStatus.xSingle + 
                  StockOptionLevel.x1 + EnvironmentSatisfaction.x2 + EnvironmentSatisfaction.x3 + 
                  EnvironmentSatisfaction.x4 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
                  JobSatisfaction.x4 + WorkLifeBalance.x2 + WorkLifeBalance.x3 + 
                  WorkLifeBalance.x4 + JobInvolvement.x3, family = "binomial", 
                data = train)
#AIC: 2100.9 hasn't changed much ,so we can remove this variable
summary(model_10)
df_vif <- data.frame(vif(model_10))

# Education 5 

model_11 <- glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + 
                  TrainingTimesLastYear + YearsSinceLastPromotion + YearsWithCurrManager + 
                  MedianHrs + BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                   JobLevel.x2 + JobRole.xHuman.Resources + JobRole.xManager + 
                  JobRole.xManufacturing.Director + JobRole.xResearch.Director + 
                  JobRole.xSales.Executive + MaritalStatus.xSingle + StockOptionLevel.x1 + 
                  EnvironmentSatisfaction.x2 + EnvironmentSatisfaction.x3 + 
                  EnvironmentSatisfaction.x4 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
                  JobSatisfaction.x4 + WorkLifeBalance.x2 + WorkLifeBalance.x3 + 
                  WorkLifeBalance.x4 + JobInvolvement.x3, family = "binomial", 
                data = train)
#AIC: 2101.7 hasn't changed much ,so we can remove this variable
summary(model_11)
df_vif <- data.frame(vif(model_11))

# Human Resources - Job Role

model_12 <- glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + 
                  TrainingTimesLastYear + YearsSinceLastPromotion + YearsWithCurrManager + 
                  MedianHrs + BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                  JobLevel.x2 +  JobRole.xManager + 
                  JobRole.xManufacturing.Director + JobRole.xResearch.Director + 
                  JobRole.xSales.Executive + MaritalStatus.xSingle + StockOptionLevel.x1 + 
                  EnvironmentSatisfaction.x2 + EnvironmentSatisfaction.x3 + 
                  EnvironmentSatisfaction.x4 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
                  JobSatisfaction.x4 + WorkLifeBalance.x2 + WorkLifeBalance.x3 + 
                  WorkLifeBalance.x4 + JobInvolvement.x3, family = "binomial", 
                data = train)
#AIC: 2103.2 hasn't changed much ,so we can remove this variable
summary(model_12)
df_vif <- data.frame(vif(model_12))

# Job Role Manager
model_13 <- glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + 
                  TrainingTimesLastYear + YearsSinceLastPromotion + YearsWithCurrManager + 
                  MedianHrs + BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                  JobLevel.x2 +  JobRole.xManufacturing.Director + 
                  JobRole.xResearch.Director + JobRole.xSales.Executive + MaritalStatus.xSingle + 
                  StockOptionLevel.x1 + EnvironmentSatisfaction.x2 + EnvironmentSatisfaction.x3 + 
                  EnvironmentSatisfaction.x4 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
                  JobSatisfaction.x4 + WorkLifeBalance.x2 + WorkLifeBalance.x3 + 
                  WorkLifeBalance.x4 + JobInvolvement.x3, family = "binomial", 
                data = train)
#AIC: 2105.6 hasn't changed much ,so we can remove this variable
summary(model_13)
df_vif <- data.frame(vif(model_13))

# Stock option 1
model_14 <- glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + 
                  TrainingTimesLastYear + YearsSinceLastPromotion + YearsWithCurrManager + 
                  MedianHrs + BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                  JobLevel.x2 + JobRole.xManufacturing.Director + JobRole.xResearch.Director + 
                  JobRole.xSales.Executive + MaritalStatus.xSingle + 
                  EnvironmentSatisfaction.x2 + EnvironmentSatisfaction.x3 + 
                  EnvironmentSatisfaction.x4 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
                  JobSatisfaction.x4 + WorkLifeBalance.x2 + WorkLifeBalance.x3 + 
                  WorkLifeBalance.x4 + JobInvolvement.x3, family = "binomial", 
                data = train)
#AIC: 2107.9 hasn't changed much ,so we can remove this variable
summary(model_14)
df_vif <- data.frame(vif(model_14))

# Job level 2
model_15 <- glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + 
                  TrainingTimesLastYear + YearsSinceLastPromotion + YearsWithCurrManager + 
                  MedianHrs + BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                   JobRole.xManufacturing.Director + JobRole.xResearch.Director + 
                  JobRole.xSales.Executive + MaritalStatus.xSingle + EnvironmentSatisfaction.x2 + 
                  EnvironmentSatisfaction.x3 + EnvironmentSatisfaction.x4 + 
                  JobSatisfaction.x2 + JobSatisfaction.x3 + JobSatisfaction.x4 + 
                  WorkLifeBalance.x2 + WorkLifeBalance.x3 + WorkLifeBalance.x4 + 
                  JobInvolvement.x3, family = "binomial", data = train)
#AIC: 2112.4 hasn't changed much ,so we can remove this variable
summary(model_15)
df_vif <- data.frame(vif(model_15))

# Job involevement x3

model_16 <- glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + 
                  TrainingTimesLastYear + YearsSinceLastPromotion + YearsWithCurrManager + 
                  MedianHrs + BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                  JobRole.xManufacturing.Director + JobRole.xResearch.Director + 
                  JobRole.xSales.Executive + MaritalStatus.xSingle + EnvironmentSatisfaction.x2 + 
                  EnvironmentSatisfaction.x3 + EnvironmentSatisfaction.x4 + 
                  JobSatisfaction.x2 + JobSatisfaction.x3 + JobSatisfaction.x4 + 
                  WorkLifeBalance.x2 + WorkLifeBalance.x3 + WorkLifeBalance.x4 , family = "binomial", data = train)
#AIC: 2116,4 hasn't changed much ,so we can remove this variable
summary(model_16)
df_vif <- data.frame(vif(model_16))

# Research Director
model_17 <- glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + 
                  TrainingTimesLastYear + YearsSinceLastPromotion + YearsWithCurrManager + 
                  MedianHrs + BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                  JobRole.xManufacturing.Director + 
                  JobRole.xSales.Executive + MaritalStatus.xSingle + EnvironmentSatisfaction.x2 + 
                  EnvironmentSatisfaction.x3 + EnvironmentSatisfaction.x4 + 
                  JobSatisfaction.x2 + JobSatisfaction.x3 + JobSatisfaction.x4 + 
                  WorkLifeBalance.x2 + WorkLifeBalance.x3 + WorkLifeBalance.x4, 
                family = "binomial", data = train)
#AIC: 2122 hasn't changed much ,so we can remove this variable
summary(model_17)
df_vif <- data.frame(vif(model_17))

# Sales executive
model_18 <- glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + 
                  TrainingTimesLastYear + YearsSinceLastPromotion + YearsWithCurrManager + 
                  MedianHrs + BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                  JobRole.xManufacturing.Director +  
                  MaritalStatus.xSingle + EnvironmentSatisfaction.x2 + EnvironmentSatisfaction.x3 + 
                  EnvironmentSatisfaction.x4 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
                  JobSatisfaction.x4 + WorkLifeBalance.x2 + WorkLifeBalance.x3 + 
                  WorkLifeBalance.x4, family = "binomial", data = train)
#AIC: 2126 hasn't changed much ,so we can remove this variable
summary(model_18)
df_vif <- data.frame(vif(model_18))

# Travel Rarely
model_19 <- glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + 
                  TrainingTimesLastYear + YearsSinceLastPromotion + YearsWithCurrManager + 
                  MedianHrs + BusinessTravel.xTravel_Frequently + 
                  JobRole.xManufacturing.Director + MaritalStatus.xSingle + 
                  EnvironmentSatisfaction.x2 + EnvironmentSatisfaction.x3 + 
                  EnvironmentSatisfaction.x4 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
                  JobSatisfaction.x4 + WorkLifeBalance.x2 + WorkLifeBalance.x3 + 
                  WorkLifeBalance.x4, family = "binomial", data = train)
#AIC: 2135.2 hasn't changed much ,so we can remove this variable
summary(model_19)
df_vif <- data.frame(vif(model_19))

# Work life balance 3 although signifcant but doesnt have business value as 2 and 4 are also available

model_20 <- glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + 
                  TrainingTimesLastYear + YearsSinceLastPromotion + YearsWithCurrManager + 
                  MedianHrs + BusinessTravel.xTravel_Frequently + JobRole.xManufacturing.Director + 
                  MaritalStatus.xSingle + EnvironmentSatisfaction.x2 + EnvironmentSatisfaction.x3 + 
                  EnvironmentSatisfaction.x4 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
                  JobSatisfaction.x4 + WorkLifeBalance.x2 + 
                  WorkLifeBalance.x4, family = "binomial", data = train)
#AIC: 2164,7 
summary(model_20)
df_vif <- data.frame(vif(model_20))

# Worklife balance 4

model_21 <- glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + 
                  TrainingTimesLastYear + YearsSinceLastPromotion + YearsWithCurrManager + 
                  MedianHrs + BusinessTravel.xTravel_Frequently + JobRole.xManufacturing.Director + 
                  MaritalStatus.xSingle + EnvironmentSatisfaction.x2 + EnvironmentSatisfaction.x3 + 
                  EnvironmentSatisfaction.x4 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
                  JobSatisfaction.x4 + WorkLifeBalance.x2 , 
                family = "binomial", data = train)
#AIC: 2162.8
summary(model_21)
df_vif <- data.frame(vif(model_21))

# Worklife balance 2 

model_22 <- glm(formula = Attrition ~ Age + NumCompaniesWorked + TotalWorkingYears + 
                  TrainingTimesLastYear + YearsSinceLastPromotion + YearsWithCurrManager + 
                  MedianHrs + BusinessTravel.xTravel_Frequently + JobRole.xManufacturing.Director + 
                  MaritalStatus.xSingle + EnvironmentSatisfaction.x2 + EnvironmentSatisfaction.x3 + 
                  EnvironmentSatisfaction.x4 + JobSatisfaction.x2 + JobSatisfaction.x3 + 
                  JobSatisfaction.x4 , family = "binomial", 
                data = train)
#AIC: 2161.2 
summary(model_22)
df_vif <- data.frame(vif(model_22))



# With 16 significant variables in the model

final_model <- model_22



### Model Evaluation ####

### Test Data ###

#predicted probabilities of Attrition 1 for test data

test_pred = predict(final_model, type = "response", 
                    newdata = test[,-2])


# Let's see the summary 

summary(test_pred)

test$prob <- test_pred
View(test)

# Let's use the probability cutoff of 50%.

test_pred_attr <- factor(ifelse(test_pred >= 0.50, "Yes", "No"))
test_actual_attr <- factor(ifelse(test$Attrition == 1,"Yes","No"))


table(test_actual_attr,test_pred_attr)
#                    test_pred_attr
# # test_actual_attr No  Yes
#                No  1051   30
#                Yes  150   59

# In this case Sentitivity is quite important and as shown above, this is not great outcome, hence
# changing threshhold to a lower value is quite important, making it 0.40
#######################################################################
test_pred_attr <- factor(ifelse(test_pred >= 0.40, "Yes", "No"))



test_conf <- confusionMatrix(test_pred_attr, test_actual_attr, positive = "Yes")
test_conf
# Accuracy : 0.855    
# Sensitivity : 0.40670
# Specificity : 0.94172 

# Let's find out the optimal probalility cutoff 

perform_fn <- function(cutoff) 
{
  predicted_attr <- factor(ifelse(test_pred >= cutoff, "Yes", "No"))
  conf <- confusionMatrix(predicted_attr, test_actual_attr, positive = "Yes")
  acc <- conf$overall[1]
  sens <- conf$byClass[1]
  spec <- conf$byClass[2]
  out <- t(as.matrix(c(sens, spec, acc))) 
  colnames(out) <- c("sensitivity", "specificity", "accuracy")
  return(out)
}

# Creating cutoff values from 0.0004469 to 0.8669 for plotting and initiallizing a matrix of 100 X 3.

# Summary of test probability

summary(test_pred)

s = seq(.01,.80,length = 100)

OUT = matrix(0,100,3)


for (i in 1:100)
{
  OUT[i,] = perform_fn(s[i])
} 

plot(s, OUT[,1],xlab = "Cutoff",ylab = "Value",cex.lab = 1.5,cex.axis = 1.5,ylim = c(0,1),type = "l",lwd = 2,axes = FALSE,col = 2)
axis(1,seq(0,1,length  = 5),seq(0,1,length = 5),cex.lab = 1.5)
axis(2,seq(0,1,length = 5),seq(0,1,length = 5),cex.lab = 1.5)
lines(s,OUT[,2],col = "darkgreen",lwd = 2)
lines(s,OUT[,3],col = 4,lwd = 2)
box()
# legend(0,.50,col=c(2,"darkgreen",4,"darkred"),lwd=c(2,2,2,2),c("Sensitivity","Specificity","Accuracy"))


cutoff <- s[which(abs(OUT[,1] - OUT[,2]) < 0.01)] # 0.1775

test_cutoff_attr <- factor(ifelse(test_pred >= .1775, "Yes", "No"))

conf_final <- confusionMatrix(test_cutoff_attr, test_actual_attr, positive = "Yes")

acc <- conf_final$overall[1]

sens <- conf_final$byClass[1]

spec <- conf_final$byClass[2]

# Accuracy 
# 0.7604
acc

# Sensitivity 
# 0.7607
sens

# Specificity 
# 0.7604
spec

View(test)

### KS -statistic - Test Data ###

test_cutoff_attr <- ifelse(test_cutoff_attr == "Yes",1,0)
test_actual_attr <- ifelse(test_actual_attr == "Yes",1,0)


library(ROCR)
# Descriminative power on the 2 classes.
#on testing  data
pred_object_test <- prediction(test_cutoff_attr, test_actual_attr)

performance_measures_test <- performance(pred_object_test, "tpr", "fpr")

acc.perf <- performance(pred_object_test, "auc")
acc.perf@y.values # Area under curve. 76.05 % 

ks_table_test <- attr(performance_measures_test, "y.values")[[1]] - 
  (attr(performance_measures_test, "x.values")[[1]])

max(ks_table_test) # 52.11 % which occurs in the 4th decile.

# Lift & Gain Chart 

# plotting the lift chart



lift <- function(labels , predicted_prob,groups=10) {
  
  if (is.factor(labels)) labels  <- as.integer(as.character(labels ))
  if (is.factor(predicted_prob)) predicted_prob <- as.integer(as.character(predicted_prob))
  helper = data.frame(cbind(labels , predicted_prob))
  helper[,"bucket"] = ntile(-helper[,"predicted_prob"], groups)
  gaintable = helper %>% group_by(bucket)  %>%
    summarise_at(vars(labels ), funs(total = n(),
                                     totalresp = sum(., na.rm = TRUE))) %>%
    
    mutate(Cumresp = cumsum(totalresp),
           Gain = Cumresp/sum(totalresp)*100,
           Cumlift = Gain/(bucket*(100/groups))) 
  return(gaintable)
}

Attrition_decile = lift(test_actual_attr, test_pred, groups = 10)
# by the 4th decile, 80 % of the people who churns out are predicted by the model, for random model it is 40 %, therefore 
# a lift of ~ 2 


