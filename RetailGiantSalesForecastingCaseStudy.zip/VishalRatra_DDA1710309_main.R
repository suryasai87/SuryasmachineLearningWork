# Check the environment for the pacakges if not there install them
if ("tidyverse" %in% rownames(installed.packages()) == FALSE)
{install.packages("tidyverse")}
if ("lubridate" %in% rownames(installed.packages()) == FALSE)
{install.packages("lubridate")}
if ("magrittr" %in% rownames(installed.packages()) == FALSE)
{install.packages("magrittr")}
if ("forecast" %in% rownames(installed.packages()) == FALSE)
{install.packages("forecast")}
if ("xts" %in% rownames(installed.packages()) == FALSE)
{install.packages("xts")}
if ("tseries" %in% rownames(installed.packages()) == FALSE)
{install.packages("tseries")}
if ("graphics" %in% rownames(installed.packages()) == FALSE)
{install.packages("graphics")}

# Load the relevant libraries
library(tidyverse)
library(lubridate)
library(magrittr)
library(forecast)
library(xts) # Extensible time series manipulations.
library(tseries)
require(graphics)

#### EDA and Data Visualisation ####
# Load the data file
df <- read_csv("Global Superstore.csv")


# Look at the structure
glimpse(df)

# Convert to date object to handle dates more easily. 
# Order Date.
df$`Order Date` <- as.Date(df$`Order Date`,format = "%d-%m-%Y")
# Shipping Date.
df$`Ship Date` <- as.Date(df$`Ship Date`,format = "%d-%m-%Y")
    
# Again Look at the structure
glimpse(df)                      
# Order and shipping dates are converted to date objecct.

# Remove the first column as it is row ID and doesnt have any physical significance  and check for duplicates
df <- df[,-1]
sum(duplicated(df))
# all the observations are unique, as sum is 0.

# For Order IDs
sum(duplicated(df$`Order ID`))
# 26255 duplicates found, as 1 order is linked to multiple product requests or transactions

# Check for missing values
sum(is.na(df))
#41296 missing values

# Lets find to which field this belongs to.
which((apply(df, 2, function(x) sum(is.na(x)))) != 0)
# Postal code is the field with NAs, as this is not a crital field it can be dropped

df %<>% select(-`Postal Code`)

# Re-Check for missing values
sum(is.na(df))

# Calculating monthly Sales, Quantity, Profit for all the 4 years for all the Market and Segments 
df %>% group_by(Market,Segment,Year = year(`Order Date`),Month = month(`Order Date`)) %>% summarise(TotalSales = sum(Sales),TotalQuantity = sum(Quantity),TotalProfit = sum(Profit)) -> dfaggr

# Calculatign coefff of variation of profit for 21 regions
# Note : absolute of the totalprofit is taken here!
dfaggr %>% group_by(Market,Segment) %>% summarise(CoeffVar = sd(TotalProfit)/mean(abs(TotalProfit))) %>% arrange(CoeffVar) -> CvProfit

# Check the 2 markets and segements which CoeffofVar of Profit is least and hence stable.
CvProfit[1:2,]

# Looks like "Consumer Segements" in "EU" and "APAC" markets have robust values of Profits.

# Lets validate these hypothesis by plotting
dfaggr %>% filter(Segment == 'Consumer' & Market == "EU" ) %>% data.frame() %>% select(TotalSales,TotalQuantity,TotalProfit) -> DfEU
DfEU   %>% ggplot(aes(x = 1:48,y = TotalProfit)) + geom_line() + labs(y = "TotalProfit - EU")


dfaggr %>% filter(Segment == 'Consumer' & Market == "APAC" ) %>% data.frame() %>% select(TotalSales,TotalQuantity,TotalProfit) -> DfAPAC
DfAPAC %>% ggplot(aes(x = 1:48,y = TotalProfit)) + geom_line() + labs(y = "TotalProfit - APAC")

# Handling the time series appropriately
dfts_EU <- ts(DfEU[,1:2],start = c(2011,1), frequency = 12)
autoplot(dfts_EU, facets = TRUE)

dfts_APAC <- ts(DfAPAC[,1:2],start = c(2011,1), frequency = 12)
autoplot(dfts_APAC, facets = TRUE)

# That marks the end of EDA and data handling. ####

# Please note : We would done the below using a function and call it 4 times, but  as the 
# values of tests and evaluation metric like MAPE doesnt display on console we avoided this 

# Analysis of Sales of Europe region ####
ts_analysis <- dfts_EU[,1]

# Check the seasonality of the data
ggseasonplot(ts_analysis)
# The seasonality is 12 months as shown from the above graph.
# Extract the first 3.5 years of data
train_data <- ts(ts_analysis, start = 2011, end = c(2014,6), frequency = 12)

# Lets perform the clasical decomposition.
# Using stl method for decompositoin of seasonality and trend. 

fc2 <- stl(train_data, s.window = "period")
autoplot(fc2)

fc <- forecast(fc2, h = 6)
autoplot(fc)

acf(fc$residuals)
acf(fc$residuals, type = "partial")

autoplot(ts_analysis, series = "Original Data",PI = FALSE) + 
  autolayer(fc, series = "Forecast",PI = FALSE) + 
  autolayer(fitted(fc), series = "Fitted")

# Check for stationarity 
adf.test(fc$residuals,alternative = "stationary")
kpss.test(fc$residuals)

#Now, let's compare our prediction with the actual values, using MAPE, for both training and testing data.
MAPE_train <- accuracy(fc$fitted,ts_analysis[1:42])[5]
MAPE_train
MAPE_test <- accuracy(fc$mean,ts_analysis[43:48])[5]
MAPE_test


# Classical Decomposition method 2 : Seasonaity Adjusted Moving Average method

#Smoothing the series - Centered Moving Average Smoothing
trend_Sales <- ma(train_data, order = 12, centre = T)
detrended_Sales <- train_data - trend_Sales # for additive model


# Deseasonilisation 
# calculations
m_Sales <- t(matrix(data = detrended_Sales, nrow = 12))
seasonal_Sales = colMeans(m_Sales, na.rm = T)
seasonal_Sales <- seasonal_Sales - sum(seasonal_Sales)/12 # seasonal adjustements to make sum 0 
seas <- rep(seasonal_Sales,4)

# Now deseasionalise the series
# Original series - season
deseasoned <- train_data - seas[1:42]

# Lets now model the trend on deseasoned data.
df_additive <- as.data.frame(cbind(1:42, as.vector(deseasoned)))
colnames(df_additive) <- c('Month', 'Sales')
trend_fit <- lm(Sales ~ Month , data = df_additive)
trend_add <- df_additive$Month*trend_fit$coefficients[2] + trend_fit$coefficients[1]

# Lets create the fitted model
fit_added <- trend_add + seas[1:42]

# check for randomness component - white noise
random_added <- train_data - fit_added
# Check MAPE of training data:
MAPe_train <- (100*(sum(abs((train_data - fit_added)/train_data))))/length(train_data)
MAPe_train

# Check for stationarity on the residuals
adf.test(random_added,alternative = "stationary", k = 2)
kpss.test(random_added)

# confirms white noise

# Forecasting for the next six month and check the MAPE.

forecast_add <-  c(43:48)*trend_fit$coefficients[2] + trend_fit$coefficients[1] + seas[43:48]

MAPe_test <- (100*(sum(abs((ts_analysis[43:48] - forecast_add)/ts_analysis[43:48]))))/length(ts_analysis[43:48])
MAPe_test

# Lets plot and check the results
plot(ts_analysis)
lines(ts(fit_added,start = 2011, end = c(2014,6), frequency = 12), col = "red")
lines(ts(forecast_add,start = c(2014,7), frequency = 12), type = "l",col = "green")



#So, that was classical decomposition, now let's do an ARIMA fit
# Autoarima models
# Extract 3.5 years of data using the window function.
fit <- auto.arima(window(ts_analysis,start = 2011,end = c(2014,6)))
# Forecasting the next 6 months
fit %>% forecast(h = 6) -> fc

# Checking training and test MAPE accuracy
accuracy(fc,ts_analysis)["Training set","MAPE"]
accuracy(fc,ts_analysis)["Test set","MAPE"]

#Again, let's check if the residual series is white noise
adf.test(fc$residuals,alternative = "stationary", k = 2)
kpss.test(fc$residuals)

#Lastly, let's plot the predictions along with original values, to
#get a visual feel of the fit

autoplot(ts_analysis, series = "Original Data",PI = FALSE) + 
  autolayer(fc, series = "Forecast",PI = FALSE) + 
  autolayer(fitted(fc), series = "Fitted")


#### Mmethod 2 : Automated Detection Holt WInters exponential smoothing ###
fc <- hw(ts(ts_analysis,start = 2011,end = c(2014,6),frequency = 12), seasonal = "additive", h = 6)

summary(fc)

# Checking training and test MAPE accuracy
accuracy(fc,ts_analysis)["Training set","MAPE"]
accuracy(fc,ts_analysis)["Test set","MAPE"]

#Again, let's check if the residual series is white noise
adf.test(fc$residuals,alternative = "stationary", k = 2)
kpss.test(fc$residuals)

autoplot(ts_analysis, series = "Original Data",PI = FALSE) + 
  autolayer(fc, series = "Forecast",PI = FALSE) + 
  autolayer(fitted(fc), series = "Fitted")


# End of Analysis of Sales of European Region ####


# Analysis of Quantity of Europe region ####

ts_analysis <- dfts_EU[,2]

# Check the seasonality of the data
ggseasonplot(ts_analysis)
# The seasonality is 12 months as shown from the above graph.
# Extract the first 3.5 years of data
train_data <- ts(ts_analysis, start = 2011, end = c(2014,6), frequency = 12)

# Lets perform the clasical decomposition.
# Using stl method for decompositoin of seasonality and trend. 

fc2 <- stl(train_data, s.window = "period")
autoplot(fc2)

fc <- forecast(fc2, h = 6)
autoplot(fc)

acf(fc$residuals)
acf(fc$residuals, type = "partial")

autoplot(ts_analysis, series = "Original Data",PI = FALSE) + 
  autolayer(fc, series = "Forecast",PI = FALSE) + 
  autolayer(fitted(fc), series = "Fitted")

# Check for stationarity 
adf.test(fc$residuals,alternative = "stationary")
kpss.test(fc$residuals)

#Now, let's compare our prediction with the actual values, using MAPE, for both training and testing data.
MAPE_train <- accuracy(fc$fitted,ts_analysis[1:42])[5]
MAPE_train
MAPE_test <- accuracy(fc$mean,ts_analysis[43:48])[5]
MAPE_test


# Classical Decomposition method 2 : Seasonaity Adjusted Moving Average method

#Smoothing the series - Centered Moving Average Smoothing
trend_Sales <- ma(train_data, order = 12, centre = T)
detrended_Sales <- train_data - trend_Sales # for additive model


# Deseasonilisation 
# calculations
m_Sales <- t(matrix(data = detrended_Sales, nrow = 12))
seasonal_Sales = colMeans(m_Sales, na.rm = T)
seasonal_Sales <- seasonal_Sales - sum(seasonal_Sales)/12 # seasonal adjustements to make sum 0 
seas <- rep(seasonal_Sales,4)

# Now deseasionalise the series
# Original series - season
deseasoned <- train_data - seas[1:42]

# Lets now model the trend on deseasoned data.
df_additive <- as.data.frame(cbind(1:42, as.vector(deseasoned)))
colnames(df_additive) <- c('Month', 'Sales')
trend_fit <- lm(Sales ~ Month , data = df_additive)
trend_add <- df_additive$Month*trend_fit$coefficients[2] + trend_fit$coefficients[1]

# Lets create the fitted model
fit_added <- trend_add + seas[1:42]

# check for randomness component - white noise
random_added <- train_data - fit_added
# Check MAPE of training data:
MAPe_train <- (100*(sum(abs((train_data - fit_added)/train_data))))/length(train_data)
MAPe_train

# Check for stationarity on the residuals
adf.test(random_added,alternative = "stationary", k = 2)
kpss.test(random_added)

# confirms white noise

# Forecasting for the next six month and check the MAPE.

forecast_add <-  c(43:48)*trend_fit$coefficients[2] + trend_fit$coefficients[1] + seas[43:48]

MAPe_test <- (100*(sum(abs((ts_analysis[43:48] - forecast_add)/ts_analysis[43:48]))))/length(ts_analysis[43:48])
MAPe_test

# Lets plot and check the results
plot(ts_analysis)
lines(ts(fit_added,start = 2011, end = c(2014,6), frequency = 12), col = "red")
lines(ts(forecast_add,start = c(2014,7), frequency = 12), type = "l",col = "green")

# ===

#So, that was classical decomposition, now let's do an ARIMA fit
# Autoarima models
# Extract 3.5 years of data using the window function.
fit <- auto.arima(window(ts_analysis,start = 2011,end = c(2014,6)))
# Forecasting the next 6 months
fit %>% forecast(h = 6) -> fc

# Checking training and test MAPE accuracy
accuracy(fc,ts_analysis)["Training set","MAPE"]
accuracy(fc,ts_analysis)["Test set","MAPE"]

#Again, let's check if the residual series is white noise
adf.test(fc$residuals,alternative = "stationary", k = 2)
kpss.test(fc$residuals)

#Lastly, let's plot the predictions along with original values, to
#get a visual feel of the fit

autoplot(ts_analysis, series = "Original Data",PI = FALSE) + 
  autolayer(fc, series = "Forecast",PI = FALSE) + 
  autolayer(fitted(fc), series = "Fitted")


#### Mmethod 2 : Automated Detection Holt WInters exponential smoothing ###
fc <- hw(ts(ts_analysis,start = 2011,end = c(2014,6),frequency = 12), seasonal = "additive", h = 6)

summary(fc)

# Checking training and test MAPE accuracy
accuracy(fc,ts_analysis)["Training set","MAPE"]
accuracy(fc,ts_analysis)["Test set","MAPE"]

#Again, let's check if the residual series is white noise
adf.test(fc$residuals,alternative = "stationary", k = 2)
kpss.test(fc$residuals)

autoplot(ts_analysis, series = "Original Data",PI = FALSE) + 
  autolayer(fc, series = "Forecast",PI = FALSE) + 
  autolayer(fitted(fc), series = "Fitted")



# End of Analysis of Quantity of European Region ####

# Analysis of Sales of APAC region ####

ts_analysis <- dfts_APAC[,1]

# Check the seasonality of the data
ggseasonplot(ts_analysis)
# The seasonality is 12 months as shown from the above graph.
# Extract the first 3.5 years of data
train_data <- ts(ts_analysis, start = 2011, end = c(2014,6), frequency = 12)

# Lets perform the clasical decomposition.
# Using stl method for decompositoin of seasonality and trend. 

fc2 <- stl(train_data, s.window = "period")
autoplot(fc2)

fc <- forecast(fc2, h = 6)
autoplot(fc)

acf(fc$residuals)
acf(fc$residuals, type = "partial")

autoplot(ts_analysis, series = "Original Data",PI = FALSE) + 
  autolayer(fc, series = "Forecast",PI = FALSE) + 
  autolayer(fitted(fc), series = "Fitted")

# Check for stationarity 
adf.test(fc$residuals,alternative = "stationary")
kpss.test(fc$residuals)

#Now, let's compare our prediction with the actual values, using MAPE, for both training and testing data.
MAPE_train <- accuracy(fc$fitted,ts_analysis[1:42])[5]
MAPE_train
MAPE_test <- accuracy(fc$mean,ts_analysis[43:48])[5]
MAPE_test


# Classical Decomposition method 2 : Seasonaity Adjusted Moving Average method

#Smoothing the series - Centered Moving Average Smoothing
trend_Sales <- ma(train_data, order = 12, centre = T)
detrended_Sales <- train_data - trend_Sales # for additive model


# Deseasonilisation 
# calculations
m_Sales <- t(matrix(data = detrended_Sales, nrow = 12))
seasonal_Sales = colMeans(m_Sales, na.rm = T)
seasonal_Sales <- seasonal_Sales - sum(seasonal_Sales)/12 # seasonal adjustements to make sum 0 
seas <- rep(seasonal_Sales,4)

# Now deseasionalise the series
# Original series - season
deseasoned <- train_data - seas[1:42]

# Lets now model the trend on deseasoned data.
df_additive <- as.data.frame(cbind(1:42, as.vector(deseasoned)))
colnames(df_additive) <- c('Month', 'Sales')
trend_fit <- lm(Sales ~ Month , data = df_additive)
trend_add <- df_additive$Month*trend_fit$coefficients[2] + trend_fit$coefficients[1]

# Lets create the fitted model
fit_added <- trend_add + seas[1:42]

# check for randomness component - white noise
random_added <- train_data - fit_added
# Check MAPE of training data:
MAPe_train <- (100*(sum(abs((train_data - fit_added)/train_data))))/length(train_data)
MAPe_train

# Check for stationarity on the residuals
adf.test(random_added,alternative = "stationary", k = 2)
kpss.test(random_added)

# confirms white noise

# Forecasting for the next six month and check the MAPE.

forecast_add <-  c(43:48)*trend_fit$coefficients[2] + trend_fit$coefficients[1] + seas[43:48]

MAPe_test <- (100*(sum(abs((ts_analysis[43:48] - forecast_add)/ts_analysis[43:48]))))/length(ts_analysis[43:48])
MAPe_test

# Lets plot and check the results
plot(ts_analysis)
lines(ts(fit_added,start = 2011, end = c(2014,6), frequency = 12), col = "red")
lines(ts(forecast_add,start = c(2014,7), frequency = 12), type = "l",col = "green")


#So, that was classical decomposition, now let's do an ARIMA fit
# Autoarima models
# Extract 3.5 years of data using the window function.
fit <- auto.arima(window(ts_analysis,start = 2011,end = c(2014,6)))
# Forecasting the next 6 months
fit %>% forecast(h = 6) -> fc

# Checking training and test MAPE accuracy
accuracy(fc,ts_analysis)["Training set","MAPE"]
accuracy(fc,ts_analysis)["Test set","MAPE"]

#Again, let's check if the residual series is white noise
adf.test(fc$residuals,alternative = "stationary", k = 2)
kpss.test(fc$residuals)

#Lastly, let's plot the predictions along with original values, to
#get a visual feel of the fit

autoplot(ts_analysis, series = "Original Data",PI = FALSE) + 
  autolayer(fc, series = "Forecast",PI = FALSE) + 
  autolayer(fitted(fc), series = "Fitted")


#### Mmethod 2 : Automated Detection Holt WInters exponential smoothing ###
fc <- hw(ts(ts_analysis,start = 2011,end = c(2014,6),frequency = 12), seasonal = "additive", h = 6)

summary(fc)

# Checking training and test MAPE accuracy
accuracy(fc,ts_analysis)["Training set","MAPE"]
accuracy(fc,ts_analysis)["Test set","MAPE"]

#Again, let's check if the residual series is white noise
adf.test(fc$residuals,alternative = "stationary", k = 2)
kpss.test(fc$residuals)

autoplot(ts_analysis, series = "Original Data",PI = FALSE) + 
  autolayer(fc, series = "Forecast",PI = FALSE) + 
  autolayer(fitted(fc), series = "Fitted")

# End of Analysis of sales of APAC Region ####

# Analysis of Quantity of Europe region ####


ts_analysis <- dfts_APAC[,2]

# Check the seasonality of the data
ggseasonplot(ts_analysis)
# The seasonality is 12 months as shown from the above graph.
# Extract the first 3.5 years of data
train_data <- ts(ts_analysis, start = 2011, end = c(2014,6), frequency = 12)

# Lets perform the clasical decomposition.
# Using stl method for decompositoin of seasonality and trend. 

fc2 <- stl(train_data, s.window = "period")
autoplot(fc2)

fc <- forecast(fc2, h = 6)
autoplot(fc)

acf(fc$residuals)
acf(fc$residuals, type = "partial")

autoplot(ts_analysis, series = "Original Data",PI = FALSE) + 
  autolayer(fc, series = "Forecast",PI = FALSE) + 
  autolayer(fitted(fc), series = "Fitted")

# Check for stationarity 
adf.test(fc$residuals,alternative = "stationary")
kpss.test(fc$residuals)

#Now, let's compare our prediction with the actual values, using MAPE, for both training and testing data.
MAPE_train <- accuracy(fc$fitted,ts_analysis[1:42])[5]
MAPE_train
MAPE_test <- accuracy(fc$mean,ts_analysis[43:48])[5]
MAPE_test


# Classical Decomposition method 2 : Seasonaity Adjusted Moving Average method

#Smoothing the series - Centered Moving Average Smoothing
trend_Sales <- ma(train_data, order = 12, centre = T)
detrended_Sales <- train_data - trend_Sales # for additive model


# Deseasonilisation 
# calculations
m_Sales <- t(matrix(data = detrended_Sales, nrow = 12))
seasonal_Sales = colMeans(m_Sales, na.rm = T)
seasonal_Sales <- seasonal_Sales - sum(seasonal_Sales)/12 # seasonal adjustements to make sum 0 
seas <- rep(seasonal_Sales,4)

# Now deseasionalise the series
# Original series - season
deseasoned <- train_data - seas[1:42]

# Lets now model the trend on deseasoned data.
df_additive <- as.data.frame(cbind(1:42, as.vector(deseasoned)))
colnames(df_additive) <- c('Month', 'Sales')
trend_fit <- lm(Sales ~ Month , data = df_additive)
trend_add <- df_additive$Month*trend_fit$coefficients[2] + trend_fit$coefficients[1]

# Lets create the fitted model
fit_added <- trend_add + seas[1:42]

# check for randomness component - white noise
random_added <- train_data - fit_added
# Check MAPE of training data:
MAPe_train <- (100*(sum(abs((train_data - fit_added)/train_data))))/length(train_data)
MAPe_train

# Check for stationarity on the residuals
adf.test(random_added,alternative = "stationary", k = 2)
kpss.test(random_added)

# confirms white noise

# Forecasting for the next six month and check the MAPE.

forecast_add <-  c(43:48)*trend_fit$coefficients[2] + trend_fit$coefficients[1] + seas[43:48]

MAPe_test <- (100*(sum(abs((ts_analysis[43:48] - forecast_add)/ts_analysis[43:48]))))/length(ts_analysis[43:48])
MAPe_test

# Lets plot and check the results
plot(ts_analysis)
lines(ts(fit_added,start = 2011, end = c(2014,6), frequency = 12), col = "red")
lines(ts(forecast_add,start = c(2014,7), frequency = 12), type = "l",col = "green")


#So, that was classical decomposition, now let's do an ARIMA fit
# Autoarima models
# Extract 3.5 years of data using the window function.
fit <- auto.arima(window(ts_analysis,start = 2011,end = c(2014,6)))
# Forecasting the next 6 months
fit %>% forecast(h = 6) -> fc

# Checking training and test MAPE accuracy
accuracy(fc,ts_analysis)["Training set","MAPE"]
accuracy(fc,ts_analysis)["Test set","MAPE"]

#Again, let's check if the residual series is white noise
adf.test(fc$residuals,alternative = "stationary", k = 2)
kpss.test(fc$residuals)

#Lastly, let's plot the predictions along with original values, to
#get a visual feel of the fit

autoplot(ts_analysis, series = "Original Data",PI = FALSE) + 
  autolayer(fc, series = "Forecast",PI = FALSE) + 
  autolayer(fitted(fc), series = "Fitted")


#### Mmethod 2 : Automated Detection Holt WInters exponential smoothing ###
fc <- hw(ts(ts_analysis,start = 2011,end = c(2014,6),frequency = 12), seasonal = "additive", h = 6)

summary(fc)

# Checking training and test MAPE accuracy
accuracy(fc,ts_analysis)["Training set","MAPE"]
accuracy(fc,ts_analysis)["Test set","MAPE"]

#Again, let's check if the residual series is white noise
adf.test(fc$residuals,alternative = "stationary", k = 2)
kpss.test(fc$residuals)

autoplot(ts_analysis, series = "Original Data",PI = FALSE) + 
  autolayer(fc, series = "Forecast",PI = FALSE) + 
  autolayer(fitted(fc), series = "Fitted")

# End of Analysis of Quantity of APAC region ####

