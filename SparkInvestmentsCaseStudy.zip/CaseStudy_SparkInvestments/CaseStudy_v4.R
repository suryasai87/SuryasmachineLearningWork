# Load relevant libraries.
library(tidyverse)
library(countrycode)

#Map the country code and country using the iso3c standards.
countrydf <- countrycode::countrycode_data %>% select(iso3c,country.name.en) -> cdf
colnames(cdf) <- c("country_code","Country")

#Loading the companies df
companies_df <- read.delim("companies.txt", stringsAsFactors = FALSE)
# Unique companies in companies dataset
uniquecompany_df <- data.frame(unique(companies_df$permalink))

# Convert to lower
companies_df$permalink <- tolower(companies_df$permalink)

#Loading the rounds file
rounds_df <- read.csv("rounds2.csv", stringsAsFactors = FALSE)

# Convert to lower
rounds_df$company_permalink <- tolower(rounds_df$company_permalink)
uniquerounds_df <- data.frame(unique(tolower(rounds_df$company_permalink)))

# Joining the companied and round dataframes 
master_frame <- merge(companies_df, rounds_df, by.x = "permalink", by.y = "company_permalink")


# Checkpoint2 : 
# Finding the number of NAs in raised amount usd
NumOfNAs <- sum(is.na(master_frame$raised_amount_usd))


# Use median value for imputation
master_frame$raised_amount_usd[which(is.na(master_frame$raised_amount_usd))] <- median(master_frame$raised_amount_usd, na.rm = TRUE)

# Finding the funding type based on number of investments & avg. amount raised
master_frame %>% group_by(funding_round_type) %>% summarise(cnt = n(), mean(raised_amount_usd)) %>% write_csv("Master_Frame.csv")


# Venture 10.8 Millions
# Seed .937 Millions
# PE : 62.36 Millions
# Angel : 1.10 Millions

# Choosing the Venture Funding type.
venturedf <- subset(master_frame, master_frame$funding_round_type == 'venture')

# Joining the country code and coutry with venture dataframe and finding top 9 countries
venturedf <- left_join(venturedf,cdf)
venturedf %>% group_by(Country) %>% summarise(cnt = n(), val = sum(raised_amount_usd)) %>% arrange(desc(val)) %>% top_n(9) -> top9
top9 %>% write_csv("Top9.csv")

# Top 3 English speaking countries
# US 38372
# GBR 2303
# India 992


# Sector Analysis
cc <- c("USA","GBR","IND")
venturedf %>% filter(country_code %in% cc) -> subsetventure

# Loading the mapping file 
mapping <- read_csv("mapping.csv")

# Data cleaning
mapping$category_list <- tolower(mapping$category_list)
# Replace 0 with na's 
mapping$category_list <- gsub("0", "na", mapping$category_list)
# Taking care of special case of Enterprise 2.0
mapping$category_list <- gsub("2.na", "2.0", mapping$category_list)



# Removing the blanks columns
mapping <- mapping[,-3]

# Convert the table to tall tables using gather
mapping %>% gather(Sector, Value, 2:9) %>% filter(Value == 1)  %>% select(-Value) -> map3

# Separate the venturedf into primary
# Tip : | can be searched only as a escape sequence characcter !!! 
subsetventure %>% separate(category_list, into = c("PrimaryCat"),remove = FALSE,sep = '\\|') -> newven
newven$PrimaryCat <- tolower(newven$PrimaryCat)
# Handling biotech 
newven$PrimaryCat <- gsub("biotechnology and semiconductor", "biotechnology", newven$PrimaryCat)

# Joining Primary sector with category

merged <- left_join(newven,map3, by = c("PrimaryCat" = "category_list"))

# remove rows with no Sector or NA
 merged <- merged[which(!is.na(merged$Sector)),]

# Checkpoint 6 Creating 3 dataframes with raised amount of 5 to 15 Millions
merged %>% filter(country_code == 'USA' & between(raised_amount_usd,5000000,15000000)) -> D1

merged %>% filter(country_code == 'GBR' & between(raised_amount_usd,5000000,15000000)) -> D2

merged %>% filter(country_code == 'IND' & between(raised_amount_usd,5000000,15000000)) -> D3

# total number of investments and amount in each sector for all the three countires
D1 %>% group_by(Sector) %>% 
  summarise(NumOfInvestments = n(), TotalUSD = sum(raised_amount_usd)) %>% 
  arrange(desc(NumOfInvestments)) -> D1x


D2 %>% group_by(Sector) %>% 
  summarise(NumOfInvestments = n(), TotalUSD = sum(raised_amount_usd)) %>% 
  arrange(desc(NumOfInvestments)) -> D2x


D3  %>% group_by(Sector) %>% 
  summarise(NumOfInvestments = n(), TotalUSD = sum(raised_amount_usd)) %>% 
  arrange(desc(NumOfInvestments)) -> D3x

# Finding the company name of Top 2 sectors for each country 
D1 %>% filter(Sector == 'Others') %>% 
  group_by(permalink) %>% 
  summarise(Funding = sum(raised_amount_usd)) %>% 
  arrange(desc(Funding)) %>% 
  inner_join(D1) %>% 
  select(permalink,Funding,name,status) %>%
  unique() %>% write_csv("d11x.csv")

# virtustream is acquired but capella photnics the next best is operating
D1 %>% filter(Sector == 'Social, Finance, Analytics, Advertising') %>% 
  group_by(permalink) %>% 
  summarise(Funding = sum(raised_amount_usd)) %>% 
  arrange(desc(Funding)) %>% 
  inner_join(D1) %>% 
  select(permalink,Funding,name,status) %>%
  unique() %>% write_csv("d12x.csv")
#shotspotter



D2 %>% filter(Sector == 'Others') %>% 
  group_by(permalink) %>% 
  summarise(Funding = sum(raised_amount_usd)) %>% 
  arrange(desc(Funding)) %>% 
  inner_join(D2) %>% 
  select(permalink,Funding,name,status) %>%
  unique() %>% write_csv("d21x.csv")

# electric-cloud
D2 %>% filter(Sector == 'Social, Finance, Analytics, Advertising') %>% 
  group_by(permalink) %>% summarise(Funding = sum(raised_amount_usd)) %>% 
  arrange(desc(Funding)) %>% 
  inner_join(D2) %>% 
  select(permalink,Funding,name,status) %>%
  unique() %>% write_csv("d22x.csv")
#celltick-technologies

D3 %>% filter(Sector == 'Others') %>% 
  group_by(permalink) %>% 
  summarise(Funding = sum(raised_amount_usd)) %>% 
  arrange(desc(Funding)) %>% 
  inner_join(D3) %>% 
  select(permalink,Funding,name,status) %>%
  unique() %>%  write_csv("d31x.csv")

# firstcry-com
D3 %>% filter(Sector == 'Social, Finance, Analytics, Advertising') %>% 
  group_by(permalink) %>% 
  summarise(Funding = sum(raised_amount_usd)) %>% 
  arrange(desc(Funding)) %>% 
  inner_join(D3) %>% 
  select(permalink,Funding,name,status) %>%
  unique() %>%  write_csv("d32x.csv")
#manthan-systems

