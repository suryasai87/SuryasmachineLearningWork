if ("tidyverse" %in% rownames(installed.packages()) == FALSE)
{install.packages("tidyverse")}
if ("reshape" %in% rownames(installed.packages()) == FALSE)
{install.packages("reshape")}
if ("corrgram" %in% rownames(installed.packages()) == FALSE)
{install.packages("corrgram")}
if ("gridExtra" %in% rownames(installed.packages()) == FALSE)
{install.packages("gridExtra")}

library(tidyverse)
library(reshape)
library(corrgram)
library(gridExtra)



# Load the data.
loan_df <- read.csv("loan.csv")

# Understanding the organic structure of data
glimpse(loan_df)


# Generic functiion to find null will provide you the percentage of null value in the given vector
find_null <- function(column){
  number_of_rows <- length(column)
  number_of_na <- sum(is.na(column))
  percentage_of_na_value <- (number_of_na/number_of_rows)*100
  #print(percentage_of_na_value)
  return(percentage_of_na_value)
}

null_percent <- lapply(loan_df,find_null)

# Remove all the columns in which all the entries are NAs.
loan_new_df <- loan_df[,-which(null_percent == 100) ]



# Check the organic structure of the newly created dataframe 
glimpse(loan_new_df)

# Check the summary of the dataframe -> this will give stats for numerical data and number of categories for categorical data.
summary(loan_new_df)

# By doing data exploration using summary few more columns could be dropped which are mostly zeros


# The reason why below below mentioned columns are removed.
#A. id and member id should  be removied as its unique and cant perform any calcuations on the same
#1. Emplooyee title as its doesnt have any beraing on the person defaulting the loan
#2. Payment plan as all the observations are 'n'
#3. url : as its unique for every loan id
# 4 desc : as its a free text and cant use it as not doing any text analytics here.
# 5. zip code : as its doesnt give munch information as last two elements are 'x' ed)
# 6. initial_list_Status : as all the rows are 'f'
#7: collections_12_mths_ex_med,policy_code
# 8: policy code: always 1
#9 : application type : always indivudual
# 10: Mostly zero values columns : collections_12_mths_ex_med,acc_now_delinq,chargeoff_within_12_mths,delinq_amnt,
# pub_rec_bankruptcies,tax_liens
# 11: next payment d is also blank for many 
#12: title : as eadch row is unique and same information is replicated in 'purpose'
#13 : mths_since_last_record,mths_since_last_delinq :as 36931,25682 NAs resp,
# issue_d,earliest_cr_line,last_pymnt_d,last_credit_pull_d -> removing dates as they are implictly taken care of in delinquency

rem_cols <- c("id","member_id","emp_title", "pymnt_plan","url","desc","zip_code","initial_list_status","collections_12_mths_ex_med",
              "policy_code","application_type","acc_now_delinq","chargeoff_within_12_mths","delinq_amnt","pub_rec_bankruptcies",
              "tax_liens","next_pymnt_d","title","mths_since_last_record","mths_since_last_delinq",
              "issue_d","earliest_cr_line","last_pymnt_d","last_credit_pull_d")

# Remove undesired colummns

red_df <- loan_new_df[, !names(loan_new_df) %in% rem_cols]

# Identifying categorical attributes
# term,grade, subgrade,emp_length,home_ownership,verification_status,issue_d,purpose,addr_state,
#earliest_cr_line,last_pymnt_d,last_credit_pull_d

# Identify the 'target' variable
# loan_status

# Further Data cleansing like removing blanks !!!
# Only 50 rows out of 39717 rows will be removed (0.12% of records) as it contin blank values for the column 'revol_util'
red_df %>% filter(red_df$revol_util != "") -> red_df


# Separte the data into numerical and categorical so that to perform correlation analysis
categ_cols <- c('term','grade','sub_grade','emp_length','home_ownership','verification_status','purpose','addr_state')

red_df %>% select(one_of(categ_cols)) -> df_categ
red_df %>% select(-one_of(categ_cols)) -> df_numeric

colnames(df_numeric)

options(digits = 3) # Setup for a precision of 3 decimal points

# Data cleansing by removing %
df_numeric$int_rate <- as.numeric(gsub('%', '',df_numeric$int_rate))
df_numeric$revol_util <- as.numeric(gsub('%', '',df_numeric$revol_util))

# dataframe without the 'target' variable for correlation analysis.
df_numeric_lesstarget <- df_numeric[,!names(df_numeric) %in% c("loan_status")]


# check the structure of the data
glimpse(df_numeric)
glimpse(df_numeric_lesstarget)

# Visualisations for dimensionality reduction
corrgram(df_numeric_lesstarget, order = NULL, lower.panel = panel.shade,upper.panel = panel.cor,diag.panel = panel.density,
         main = "Loans Reduction in variables")

# Further data reductions.
# Based on the correlation matrix few more columns can be dropped- threshhold 70 % 
rem_cols <- c("funded_amnt",
              "funded_amnt_inv",
              "installment",
              "total_pymnt",
              "total_pymnt_inv",
              "total_rec_prncp",
              "total_rec_int",
              "out_prncp_inv",
              "collection_recovery_fee")

df_numeric %>% select(-one_of(rem_cols)) -> df_numeric_remcor

# Check correlation matrix of reduced dataset 
corrgram(df_numeric_remcor, order = NULL, lower.panel = panel.shade,upper.panel = panel.cor,diag.panel = panel.density,
         main = "Loans Reduction in variables- uncorr")

# Section Exploratory Analysis 

#Column commbines
mega_df <- cbind(df_numeric_remcor, df_categ)

# We will only consider the fully paid and charged of data as current
# can default or not, We are not interestd in that
# Check how the interest varies for loan status

mega_df %>% filter(loan_status != 'Current') -> mega_df

# 
find_pvalue <- function(column_name){
  idx_chargedoff <- which(mega_df$loan_status == 'Charged Off') 
  data1 <- mega_df[idx_chargedoff,column_name]
  data2 <- mega_df[-idx_chargedoff,column_name]
  p1 <- t.test(data1, data2)
  return(p1$p.value)
}


#Subset for Fully Paid and Charged off data sets
mega_df_fpaid <- filter(mega_df,loan_status == 'Fully Paid')
megadf_chargedoff <- filter(mega_df,loan_status == 'Charged Off')





# Analysis of variables

###variable of interest last_pymnt_amnt

#last_pymnt_amnt vs Loan Status Box Plot
mega_df  %>% ggplot() + aes(x = loan_status,y = last_pymnt_amnt ) +  geom_boxplot(alpha = 0,fill = "white", colour = "#3366FF") 

#Box plot distribution shown below:
summarise(group_by(mega_df,loan_status), median =  median(last_pymnt_amnt,na.rm = TRUE))
#Median
#Charged Off 239
#Fully Paid  865

quantile(mega_df_fpaid$last_pymnt_amnt)
#paid
#0%     25%     50%     75%       100% 
#0      255     865     4255       36115 

quantile(megadf_chargedoff$last_pymnt_amnt)
#chargedoff
#0%     25%     50%     75%     100% 
#0      114     239     406     12818 

#There is a difference in interquartile range clearly and hence this is a differentiator

#Hypothesis Testing
last_pymnt_amnt_pvalue <- find_pvalue("last_pymnt_amnt")
#pvalue 0  which is very small so this variable has impact on Loan Status


###variable of interest recoveries

#recoveries vs Loan Status Box Plot
mega_df  %>% ggplot() + aes(x = loan_status,y = recoveries ) +  geom_boxplot(alpha = 0,fill = "white", colour = "#3366FF") 

#Box plot distribution shown below:
summarise(group_by(mega_df,loan_status), median =  median(recoveries,na.rm = TRUE))
#Median
#Charged Off 173
#Fully Paid  0

quantile(mega_df_fpaid$recoveries)

#paid
#0%     25%     50%     75%       100% 
#0      0     0     0       0 

quantile(megadf_chargedoff$recoveries)
#chargedoff
#0%     25%     50%     75%     100% 
#0      0     173     596     29623 

#There is a difference in interquartile range clearly and hence this is a differentiator

#Hypothesis Testing
recoveries_pvalue <- find_pvalue("recoveries")
#pvalue 2.934e-175  which is very small so this variable has impact on Loan Status


###variable of interest total_rec_late_fee

#total_rec_late_fee vs Loan Status Box Plot
mega_df  %>% ggplot() + aes(x = loan_status,y = total_rec_late_fee ) +  geom_boxplot(alpha = 0,fill = "white", colour = "#3366FF") 

#Box plot distribution shown below:
summarise(group_by(mega_df,loan_status), median =  median(total_rec_late_fee,na.rm = TRUE))
#Median
#Charged Off 0
#Fully Paid  0

quantile(mega_df_fpaid$total_rec_late_fee)
#paid
#0%     25%     50%     75%       100% 
#0      0     0     0       166 

quantile(megadf_chargedoff$total_rec_late_fee)
#chargedoff
#0%     25%     50%     75%     100% 
#0      0     0     0     180 

#There is a difference in interquartile range clearly and hence this is a differentiator

#Hypothesis Testing
total_rec_late_fee_pvalue <- find_pvalue("total_rec_late_fee")
#pvalue 0  which is very small so this variable has impact on Loan Status
total_rec_late_fee_pvalue


#Now lets start considering all numeric variables for analysis

#dti vs Loan Status Box Plot to see the variations for Fully paid and Charged off with dti values
mega_df  %>% ggplot() + aes(x = loan_status,y = dti ) +  geom_boxplot(alpha = 0,fill = "white", colour = "#3366FF") 

#Box plot distribution shown below:
summarise(group_by(mega_df,loan_status), median(dti,na.rm = TRUE))
#Median: Charged Off 14.3 Fully Paid  13.2
quantile(mega_df_fpaid$dti) 
#0%   25%   50%   75%  100% 
#0.00  7.99 13.20 18.40 29.99
quantile(megadf_chargedoff$dti)
#0%   25%   50%   75%  100% 
#0.00  9.05 14.31 19.29 29.85
#in all the above percentile there seems to be constant difference between fully paid and charged of so this is worth considering

#Hypothesis Testing
dti_pvalue <- find_pvalue("dti")
# p Value = 4.5 e -19 which is very small so this variable has impact on Loan Status

#inq_last_6mths vs Loan Status Box Plot
mega_df  %>% ggplot() + aes(x = loan_status,y = inq_last_6mths ) +  geom_boxplot(alpha = 0,fill = "white", colour = "#3366FF") 

#Box plot distribution shown below:
summarise(group_by(mega_df,loan_status), median(inq_last_6mths,na.rm = TRUE))
#Median : Charged Off 1 Fully Paid  1
quantile(mega_df_fpaid$inq_last_6mths)
#0%  25%  50%  75% 100% 
#0    0    1    1    8 
quantile(megadf_chargedoff$inq_last_6mths)
#0%  25%  50%  75% 100% 
#0    0    1    2    8 
# quantile variations after 50 percentile shows clearly an impact and hence this is an impact variable

inq_6mths_pvalue <- find_pvalue("inq_last_6mths")
#pvalue = 1.19 e-39 which is very small so this variable has impact on Loan Status

#open_acc vs loan Status box plot
mega_df  %>% ggplot() + aes(x = loan_status,y = open_acc ) +  geom_boxplot(alpha = 0,fill = "white", colour = "#3366FF") 

summarise(group_by(mega_df,loan_status), median(open_acc,na.rm = TRUE))
#Median: Charged Off 9 Fully Paid  9
quantile(mega_df_fpaid$open_acc)
#0%  25%  50%  75% 100% 
#2    6    9   12   44 
quantile(megadf_chargedoff$open_acc)
#0%  25%  50%  75% 100% 
#2    6    9   12   38 
# We don't see any significant difference in quantile values so this may not be a good indicator

#t-test to confirm the above point
open_acc_pvalue <- find_pvalue("open_acc")

#pvalue = 0.113
#Pvalue is pretty high so this variable doesn't have any impact on the Loan Status. 

#public_rec vs loan Status box plot
mega_df  %>% ggplot() + aes(x = loan_status,y = pub_rec) +  geom_boxplot(alpha = 0,fill = "white", colour = "#3366FF") 
summarise(group_by(mega_df,loan_status), median(pub_rec,na.rm = TRUE))
#Median: Charged Off 0 Fully Paid  0
# above plot and summary shows that this variable is not worthy for further analysis

#revol_util vs Loan Status Box Plot
mega_df  %>% ggplot() + aes(x = loan_status,y = revol_util ) +  geom_boxplot(alpha = 0,fill = "white", colour = "#3366FF") 
#Box plot distribution shown below:
summarise(group_by(mega_df,loan_status), median(revol_util,na.rm = TRUE))
#Median Charged Off 58.4,Fully Paid  47.6
quantile(mega_df_fpaid$revol_util)
# 0%    25%    50%    75%   100% 
#0.0 23.9 47.6 70.8 99.9
quantile(megadf_chargedoff$revol_util)
# 0%    25%    50%    75%   100% 
# 0.0 34.4 58.4 79.0 99.9
# Consistent variation across quantiles therefore impactful variable
#Hypothesis Testing
revol_util_pvalue <- find_pvalue("revol_util")
# p Value < 2e-16, which is very small so this variable has impact on Loan Status 


#total_acc vs Loan Status Box Plot
mega_df  %>% ggplot() + aes(x = loan_status,y = total_acc ) +  geom_boxplot(alpha = 0,fill = "white", colour = "#3366FF") 
#Box plot distribution shown below:
summarise(group_by(mega_df,loan_status), median(total_acc,na.rm = TRUE))
#Median Charged Off 20,Fully Paid  21
quantile(mega_df_fpaid$total_acc)
# 0%    25%    50%    75%   100% 
#2   14   21   29   90
quantile(megadf_chargedoff$total_acc)
# 0%    25%    50%    75%   100% 
# 2   13   20   28   74
# Consistent variation across quantiles therefore impactful variable
#Hypothesis Testing
total_acc_pvalue <- find_pvalue("total_acc")
# p Value = 2e-05,, which is very small so this variable has impact on Loan Status

#revol_bal vs Loan Status Box Plot
mega_df  %>% ggplot() + aes(x = loan_status,y = revol_bal ) +  geom_boxplot(alpha = 0,fill = "white", colour = "#3366FF") 
#Box plot distribution shown below:
summarise(group_by(mega_df,loan_status), median(revol_bal,na.rm = TRUE))
#Median Charged Off 9253,Fully Paid  8694
quantile(mega_df_fpaid$revol_bal)
# 0%    25%    50%    75%   100% 
# 0   3612   8694  16828 149588
quantile(megadf_chargedoff$revol_bal)
# 0%    25%    50%    75%   100% 
# 0   4007   9253  17554 148829
# Consistent variation across quantiles therefore impactful variable
#Hypothesis Testing
revol_bal_pvalue <- find_pvalue("revol_bal")
# p Value = 0.2,, which is higher than 0.05 hence cannot be a driver

#oustdn_prncp vs Loan Status Box Plot
mega_df  %>% ggplot() + aes(x = loan_status,y = out_prncp ) +  geom_boxplot(alpha = 0,fill = "white", colour = "#3366FF") 
#Box plot distribution shown below:
summarise(group_by(mega_df,loan_status), median(out_prncp,na.rm = TRUE))
#Median Charged Off 0,Fully Paid  0
quantile(mega_df_fpaid$out_prncp)
# 0%    25%    50%    75%   100% 
# 0    0    0    0    0
quantile(megadf_chargedoff$out_prncp)
# 0%    25%    50%    75%   100% 
# 0    0    0    0    0
# Consistent variation across quantiles therefore impactful variable
#Hypothesis Testing
out_prncp_pvalue <- find_pvalue("out_prncp")

# p Value = not defined, can't be driver

###variable of interest loan_amnt

#loan_amnt vs Loan Status Box Plot
mega_df  %>% ggplot() + aes(x = loan_status,y = loan_amnt ) +  geom_boxplot(alpha = 0,fill = "white", colour = "#3366FF") 

#Box plot distribution shown below:
summarise(group_by(mega_df,loan_status), median =  median(loan_amnt,na.rm = TRUE))
#Median
#Charged Off 10000
#Fully Paid  9600

quantile(mega_df_fpaid$loan_amnt)
#paid
#0%     25%     50%     75%       100% 
#500    5200    9600    15000    35000 

quantile(megadf_chargedoff$loan_amnt)
#chargedoff
#0%     25%     50%     75%     100% 
#900    5600    10000   16500   35000 

#There is a difference in interquartile range clearly and hence this is a differentiator

#Hypothesis Testing
loan_amnt_pvalue <- find_pvalue("loan_amnt")
#pvalue <2e-16  which is very small so this variable has impact on Loan Status



###variable of interest int_rate
#int_rate vs Loan Status Box Plot
mega_df  %>% ggplot() + aes(x = loan_status,y = int_rate ) +  geom_boxplot(alpha = 0,fill = "white", colour = "#3366FF") 

#Box plot distribution shown below:
summarise(group_by(mega_df,loan_status), median =  median(int_rate,na.rm = TRUE))
#Median
#Charged Off 13.6
#Fully Paid  11.5

quantile(mega_df_fpaid$int_rate)
#paid
#0%       25%     50%     75%       100% 
#5.42    8.49    11.49    13.99    24.11 

quantile(megadf_chargedoff$int_rate)
#chargedoff
#0%     25%     50%     75%     100% 
#5.42   11.28   13.57   16.40   24.40 

# there is a difference in interquartile range clearly and hence this is a differentiator

#Hypothesis Testing
int_rate_pvalue <- find_pvalue("int_rate")
#pvalue <2e-16 which is very small so this variable has impact on Loan Status



### variable of interest annual_inc

med <- median(mega_df$annual_inc)
med
#median = 59000
mean <- mean(mega_df$annual_inc)
#mean = 68809
quantile(mega_df_fpaid$annual_inc)
#distribution of annual_inc
#0%     25%     50%     75%    100% 
#4000   41295   60000   84000 6000000 

iqr <- IQR(mega_df$annual_inc, na.rm = TRUE)
iqr
#iqr = 42000
outliers <- med + 1.5 * iqr
outliers
#thresholds for outliers = 122000
annual_inc_df <- mega_df[mega_df$annual_inc < outliers,]
quantile(annual_inc_df$annual_inc)
#new distribution of annual_inc after removing of outliers
#0%    25%    50%    75%   100% 
#4000  40000  55000  75000 121900 

#creating two data frame from the new data frame.
annual_inc_df_paidoff <- filter(annual_inc_df,loan_status == 'Fully Paid')
annual_inc_df_chargedoff <- filter(annual_inc_df,loan_status == 'Charged Off')
#after Removing outliers 

#annual_inc vs Loan Status Box Plot
annual_inc_df  %>% ggplot() + aes(x = loan_status,y = annual_inc ) +  geom_boxplot(alpha = 0,fill = "white", colour = "#3366FF") 

#Box plot distribution shown below:
summarise(group_by(annual_inc_df,loan_status), median =  median(annual_inc,na.rm = TRUE))
quantile(annual_inc_df_paidoff$annual_inc)
#paid
#0%       25%     50%     75%       100% 
#4000    40000   55200   75000    121722
quantile(annual_inc_df_chargedoff$annual_inc)
#chargedoff
#0%     25%     50%     75%     100% 
#4080 36000     50400  70000   121900
# there is a difference in interquartile range clearly and hence this is a differentiator
#Hypothesis Testing
annual_inc_pvalue <- find_pvalue("annual_inc")
#pvalue = 1.19 e-39 which is very small so this variable has impact on Loan Status



# Study of categorical variable - Grade

plot1 <- ggplot(mega_df, aes(x = as.factor(grade), fill = loan_status)) + geom_bar(position = "dodge") + labs(x = "grade", y = "Count" )
plot2 <- ggplot(mega_df, aes(x = as.factor(grade), fill = loan_status)) + geom_bar(position = "fill") + labs(x = "grade", y = "Proportion" )

grid.arrange(plot1, plot2, ncol = 2)
table(factor(mega_df$loan_status),mega_df$grade)


# Study of categorical variable - Sub Grade

plot1 <- ggplot(mega_df, aes(x = as.factor(sub_grade), fill = loan_status)) + geom_bar(position = "dodge") + labs(x = "sub_grade", y = "Count" )
plot2 <- ggplot(mega_df, aes(x = as.factor(sub_grade), fill = loan_status)) + geom_bar(position = "fill") + labs(x = "sub_grade", y = "Proportion" )

grid.arrange(plot1, plot2, ncol = 2)
table(factor(mega_df$loan_status),mega_df$sub_grade)


# Study of categorical variable - Delinquent last 2 years

plot1 <- ggplot(mega_df, aes(x = as.factor(delinq_2yrs), fill = loan_status)) + geom_bar(position = "dodge") + labs(x = "delinq_2yrs", y = "Count" )
plot2 <- ggplot(mega_df, aes(x = as.factor(delinq_2yrs), fill = loan_status)) + geom_bar(position = "fill") + labs(x = "delinq_2yrs", y = "Proportion" )

grid.arrange(plot1, plot2, ncol = 2)
table(factor(mega_df$loan_status),mega_df$delinq_2yrs)

# Home Ownership with Loan status: 
plot1 <- ggplot(mega_df, aes(x = as.factor(home_ownership), fill = loan_status)) + geom_bar(position = "dodge") + labs(x = "Home Ownership", y = "Count" )
plot2 <- ggplot(mega_df, aes(x = as.factor(home_ownership), fill = loan_status)) + geom_bar(position = "fill") + labs(x = "Home Ownership", y = "Count" )
#Use Grid to arrange the plots side by side to compare and table to compare the numbers
grid.arrange(plot1, plot2, ncol = 2) 
table(factor(mega_df$loan_status),mega_df$home_ownership)
#From the plots and table, it doesn't seem that Homeownership has a major impact on Loan Status
#Others and None are more in proportion but Numbers wise the entries are pretty less to judge. 


# Verification Status with Loan status: 
plot1 <- ggplot(mega_df, aes(x = as.factor(verification_status), fill = loan_status)) + geom_bar(position = "dodge") + labs(x = "Verification Status", y = "Count" )
plot2 <- ggplot(mega_df, aes(x = as.factor(verification_status), fill = loan_status)) + geom_bar(position = "fill") + labs(x = "Verification Status", y = "Count" )

grid.arrange(plot1, plot2, ncol = 2) 
table(factor(mega_df$loan_status),mega_df$verification_status)
#From the plots and table, it seems that the verified ones are more prone to default than the other two categories
#Source verified is the best one with list percentage of defaults

### variable of interest emp_length

# Verification emp_length with Loan status: 
plot1 <- ggplot(mega_df, aes(x = as.factor(emp_length), fill = loan_status)) + geom_bar(position = "dodge") + labs(x = "emp_lenght", y = "Count" ) 
plot2 <- ggplot(mega_df, aes(x = as.factor(emp_length), fill = loan_status)) + geom_bar(position = "fill") + labs(x = "emp_lenght", y = "Proportion" )  
grid.arrange(plot1, plot2, ncol = 2) 
table(factor(mega_df$loan_status),mega_df$emp_length)

### variable of interest term

# Purpose term with Loan status: 
plot1 <- ggplot(mega_df, aes(x = as.factor(purpose), fill = loan_status)) + geom_bar(position = "dodge") + labs(x = "purpose", y = "Count" ) + theme(axis.text.x = element_text(angle = 90, hjust = 0))  
plot2 <- ggplot(mega_df, aes(x = as.factor(purpose), fill = loan_status)) + geom_bar(position = "fill") + labs(x = "purpose", y = "Proportion" )  +  theme(axis.text.x = element_text(angle = 90, hjust = 0)) 
grid.arrange(plot1, plot2, ncol = 2)  
table(factor(mega_df$loan_status),mega_df$purpose)


plot1 <- ggplot(mega_df, aes(x = as.factor(addr_state), fill = loan_status)) + geom_bar(position = "dodge") + labs(x = "Address State", y = "Count" ) 
plot2 <- ggplot(mega_df, aes(x = as.factor(addr_state), fill = loan_status)) + geom_bar(position = "fill") + labs(x = "Address State", y = "Count" )  
grid.arrange(plot1, plot2, ncol = 2)  
table(factor(mega_df$loan_status),mega_df$addr_state)

#Categorical Bivariate analysis Plots

mega_df  %>% ggplot() + aes(x = grade,y = int_rate, color = grade) +
  geom_boxplot() + facet_wrap(~ loan_status)

mega_df  %>% ggplot() + aes(x = term,y = int_rate, color = term) +
  geom_boxplot() + facet_wrap(~ loan_status)

mega_df  %>% ggplot() + aes(x = term,y = dti, color = term) +
  geom_boxplot() + facet_wrap(~ loan_status)

mega_df  %>% ggplot() + aes(x = grade,y = dti, color = grade) +
  geom_boxplot() + facet_wrap(~ loan_status)